"""
Agent 1: Page Structure Analyzer

Extracts and analyzes ALL web page elements using Playwright.
Analyzes buttons, links, inputs, forms, and other interactive elements.
Identifies relationships between elements and fields.
"""
import asyncio
import json
import sys
from playwright.async_api import async_playwright, Page
from utils.version_manager import VersionManager


async def get_fields_in_visual_order(page: Page) -> list:
    """Get all input fields in their exact visual order on the page."""
    inputs = await page.query_selector_all('input:visible, textarea:visible, select:visible')
    fields_with_pos = []
    
    for inp in inputs:
        try:
            inp_name = await inp.get_attribute('name') or ''
            inp_id = await inp.get_attribute('id') or ''
            inp_type = await inp.get_attribute('type') or 'text'
            placeholder = await inp.get_attribute('placeholder') or ''
            
            if not (inp_name or inp_id):
                continue
            
            # Get position for sorting
            box = await inp.bounding_box()
            if box:
                fields_with_pos.append({
                    'name': inp_name,
                    'type': inp_type,
                    'id': inp_id,
                    'placeholder': placeholder,
                    'y': box['y'],
                    'x': box['x']
                })
        except:
            continue
    
    # Sort by Y position (top to bottom), then X position (left to right)
    fields_with_pos.sort(key=lambda f: (f['y'], f['x']))
    
    # Remove position data, keep only field info
    return [{'name': f['name'], 'type': f['type'], 'id': f['id'], 'placeholder': f['placeholder']} 
            for f in fields_with_pos]


async def analyze_page(url: str, headless: bool = True) -> dict:
    """
    Analyze web page and extract buttons and fields.
    
    Args:
        url: URL of the web page to analyze
        headless: Whether to run browser in headless mode
        
    Returns:
        Dictionary containing analysis of buttons and fields
    """
    print(f"\nAgent 1: Analyzing page structure")
    print(f"URL: {url}")
    print("=" * 60)
    
    # Open browser and extract elements
    print("\nOpening browser and extracting elements...")
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=headless)
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        )
        page = await context.new_page()
        
        try:
            # Navigate to URL
            await page.goto(url, wait_until='networkidle', timeout=30000)
            await page.wait_for_timeout(3000)  # Wait for JavaScript to render
            
            # Get page info
            title = await page.title()
            current_url = page.url
            
            # Extract buttons using Playwright - comprehensive approach
            print("Extracting buttons using Playwright...")
            
            # Method 1: Get all buttons globally - analyze page exactly as it is
            print("  [Method 1] Finding all buttons globally (including tabs)...")
            all_buttons_global = await page.query_selector_all(
                'button, '
                'input[type="button"], '
                'input[type="submit"], '
                'input[type="reset"], '
                'button[type="submit"], '
                'button[type="button"], '
                '[role="button"], '
                '[role="tab"], '  # Include tab buttons
                '[onclick], '
                'a[role="button"], '
                'a[role="tab"]'  # Include tab links
            )
            print(f"    Found {len(all_buttons_global)} buttons globally (including tabs)")
            
            # Also specifically find tab buttons
            print("  [Method 1.5] Finding tab buttons specifically...")
            tab_buttons = await page.query_selector_all(
                '[role="tab"], '
                'button[class*="tab"], '
                'button[class*="Tab"], '
                'a[role="tab"], '
                '.tab-button, '
                '[data-tab], '
                '[aria-controls*="tab"]'
            )
            print(f"    Found {len(tab_buttons)} tab-specific elements")
            
            # Add tab buttons that might not be in the main list
            for tab_btn in tab_buttons:
                try:
                    # Check if already in list
                    is_duplicate = False
                    for existing_btn in all_buttons_global:
                        try:
                            same = await page.evaluate('''([btn1, btn2]) => {
                                return btn1 === btn2;
                            }''', [tab_btn, existing_btn])
                            if same:
                                is_duplicate = True
                                break
                        except:
                            pass
                    if not is_duplicate:
                        all_buttons_global.append(tab_btn)
                        print(f"      Added tab button to analysis")
                except:
                    continue
            
            # Method 2: Get all forms and find submit buttons in each form
            print("  [Method 2] Finding submit buttons in forms...")
            forms = await page.query_selector_all('form')
            form_buttons = []
            
            for form in forms:
                try:
                    # Find all submit buttons inside this form
                    form_submit_buttons = await form.query_selector_all(
                        'button[type="submit"], '
                        'input[type="submit"], '
                        'button:not([type]), '  # buttons without type default to submit in forms
                        '[type="submit"]'
                    )
                    
                    for btn in form_submit_buttons:
                        if btn not in all_buttons_global:
                            form_buttons.append(btn)
                            print(f"    Found additional submit button in form")
                except:
                    continue
            
            # Combine all buttons
            all_buttons = list(all_buttons_global) + form_buttons
            print(f"  Total unique buttons found: {len(all_buttons)}")
            
            # Also use Playwright's locator to find buttons by text/content
            print("  [Method 3] Finding buttons by text patterns...")
            try:
                # Find buttons that might have submit-related text
                submit_texts = ['submit', 'create', 'save', 'register', 'sign up', 'join', 'login']
                for text_pattern in submit_texts:
                    try:
                        locator_buttons = await page.locator(f'button:has-text("{text_pattern}"), input[value*="{text_pattern}"]').all()
                        for btn in locator_buttons:
                            if btn not in all_buttons:
                                all_buttons.append(btn)
                                print(f"    Found button with text pattern: {text_pattern}")
                    except:
                        continue
            except:
                pass
            
            # Process all found buttons - capture ALL instances, even duplicates
            button_list = []
            button_elements_map = []
            seen_elements = set()  # Track by element handle ID to avoid processing same DOM element twice
            
            for idx, button in enumerate(all_buttons):
                try:
                    # Get element's unique identifier - use multiple properties to ensure uniqueness
                    # Include position, text, and a unique identifier from the DOM
                    try:
                        element_unique = await button.evaluate('''el => {
                            const rect = el.getBoundingClientRect();
                            return {
                                html: el.outerHTML.substring(0, 200), // First 200 chars of HTML
                                x: Math.round(rect.x * 10) / 10, // Round to 1 decimal
                                y: Math.round(rect.y * 10) / 10,
                                id: el.id || '',
                                text: (el.innerText || el.value || '').substring(0, 50),
                                index: Array.from(el.parentElement?.children || []).indexOf(el)
                            };
                        }''')
                        element_id = f"{element_unique['html']}_{element_unique['x']}_{element_unique['y']}_{element_unique['id']}_{element_unique['text']}_{element_unique['index']}"
                    except:
                        # Fallback: use simpler identifier
                        box = await button.bounding_box()
                        text = await button.inner_text() or await button.get_attribute('value') or ''
                        btn_id = await button.get_attribute('id') or ''
                        element_id = f"{btn_id}_{text}_{box['x'] if box else 0}_{box['y'] if box else 0}_{idx}"
                    
                    # IMPORTANT: Allow duplicates - only skip if it's the exact same DOM element
                    # Use element handle comparison to check if it's the same DOM node
                    is_duplicate_dom_element = False
                    for btn_map in button_elements_map:
                        seen_btn_element = btn_map['element']
                        # Compare by checking if they're the same element in DOM
                        try:
                            same_element = await page.evaluate('''([btn1, btn2]) => {
                                return btn1 === btn2;
                            }''', [button, seen_btn_element])
                            if same_element:
                                is_duplicate_dom_element = True
                                break
                        except:
                            pass
                    
                    if is_duplicate_dom_element:
                        print(f"    Skipping exact same DOM element")
                        continue
                    
                    # Track this element (but allow duplicates with same text/id at different positions)
                    seen_elements.add(element_id)
                    
                    # Get button properties
                    text = await button.inner_text() or await button.get_attribute('value') or ''
                    button_id = await button.get_attribute('id') or ''
                    button_type = await button.get_attribute('type') or 'button'
                    tag = await button.evaluate('el => el.tagName.toLowerCase()')
                    button_class = await button.get_attribute('class') or ''
                    
                    # Get position for tracking
                    box = await button.bounding_box()
                    position_key = f"{box['x']:.1f}_{box['y']:.1f}" if box else f"pos_{idx}"
                    
                    is_visible = await button.is_visible()
                    
                    if not is_visible:
                        continue
                    
                    # For buttons without explicit type, check if they're in a form (defaults to submit)
                    if tag == 'button' and not button_type:
                        form_info = await button.evaluate('''el => {
                            let parent = el.closest('form');
                            if (parent) {
                                return {
                                    id: parent.id || '',
                                    action: parent.action || '',
                                    method: parent.method || 'get'
                                };
                            }
                            return null;
                        }''')
                        if form_info:
                            button_type = 'submit'  # Button in form without type is submit
                    else:
                        form_info = None
                        if button_type == 'submit' or tag == 'button':
                            try:
                                form_info = await button.evaluate('''el => {
                                    let parent = el.closest('form');
                                    if (parent) {
                                        return {
                                            id: parent.id || '',
                                            action: parent.action || '',
                                            method: parent.method || 'get'
                                        };
                                    }
                                    return null;
                                }''')
                            except:
                                pass
                    
                    # Check if this is a tab button
                    is_tab = False
                    role = await button.get_attribute('role') or ''
                    if role == 'tab' or 'tab' in button_class.lower() or 'tab' in str(await button.get_attribute('data-tab') or ''):
                        is_tab = True
                    
                    # Create unique identifier for each button (even if text/id is same)
                    # Include position in unique_id to distinguish duplicates
                    # Use element_id as part of unique_id to ensure uniqueness
                    unique_id = f"btn_{len(button_list)}_{position_key}_{element_id[:20]}"
                    button_data = {
                        "text": text.strip(),
                        "type": button_type,
                        "id": button_id,
                        "class": button_class,
                        "tag": tag,
                        "form": form_info,
                        "position": position_key,
                        "is_tab": is_tab,  # Mark if this is a tab button
                        "role": role,
                        "index": len(button_list),  # Use sequential index based on actual list
                        "unique_id": unique_id,  # Unique identifier for this button instance
                        "element_id": element_id  # Store element_id for duplicate checking
                    }
                    
                    button_list.append(button_data)
                    button_elements_map.append({
                        'data': button_data,
                        'element': button,  # Store the actual element
                        'element_id': element_id,
                        'original_index': idx  # Keep original index to track duplicates
                    })
                    
                    # Log if this is a duplicate (same text but different position)
                    if len([b for b in button_list if b.get('text', '').strip() == text.strip()]) > 1:
                        print(f"    Added duplicate button: '{text.strip()}' (position: {position_key})")
                except Exception as e:
                    print(f"    Error processing button {idx}: {e}")
                    continue
            
            print(f"  Final count: {len(button_list)} unique button elements")
            
            # Extract input fields
            print("Extracting input fields...")
            inputs = await page.query_selector_all('input, textarea, select')
            input_list = []
            
            for input_elem in inputs:
                try:
                    input_type = await input_elem.get_attribute('type') or 'text'
                    input_name = await input_elem.get_attribute('name') or ''
                    input_id = await input_elem.get_attribute('id') or ''
                    placeholder = await input_elem.get_attribute('placeholder') or ''
                    is_visible = await input_elem.is_visible()
                    
                    if not is_visible:
                        continue
                    
                    input_list.append({
                        "name": input_name,
                        "type": input_type,
                        "id": input_id,
                        "placeholder": placeholder,
                        "tag": await input_elem.evaluate('el => el.tagName.toLowerCase()')
                    })
                except:
                    continue
            
            # Extract links
            print("Extracting links...")
            links = await page.query_selector_all('a[href]')
            link_list = []
            
            for link in links:
                try:
                    text = await link.inner_text() or ''
                    href = await link.get_attribute('href') or ''
                    link_id = await link.get_attribute('id') or ''
                    link_class = await link.get_attribute('class') or ''
                    is_visible = await link.is_visible()
                    
                    if not is_visible:
                        continue
                    
                    link_list.append({
                        "text": text.strip(),
                        "href": href,
                        "id": link_id,
                        "class": link_class,
                        "tag": await link.evaluate('el => el.tagName.toLowerCase()')
                    })
                except:
                    continue
            
            # Extract forms
            print("Extracting forms...")
            forms = await page.query_selector_all('form')
            form_list = []
            
            for form in forms:
                try:
                    form_id = await form.get_attribute('id') or ''
                    form_action = await form.get_attribute('action') or ''
                    form_method = await form.get_attribute('method') or 'get'
                    form_class = await form.get_attribute('class') or ''
                    is_visible = await form.is_visible()
                    
                    if not is_visible:
                        continue
                    
                    # Get fields in this form
                    form_inputs = await form.query_selector_all('input, textarea, select')
                    form_fields = []
                    for inp in form_inputs:
                        try:
                            inp_name = await inp.get_attribute('name') or ''
                            inp_id = await inp.get_attribute('id') or ''
                            inp_type = await inp.get_attribute('type') or 'text'
                            if (inp_name or inp_id) and await inp.is_visible():
                                form_fields.append({
                                    'name': inp_name,
                                    'type': inp_type,
                                    'id': inp_id
                                })
                        except:
                            continue
                    
                    form_list.append({
                        "id": form_id,
                        "action": form_action,
                        "method": form_method,
                        "class": form_class,
                        "fields": form_fields,
                        "field_count": len(form_fields)
                    })
                except:
                    continue
            
            # Extract other clickable/interactive elements
            print("Extracting other interactive elements...")
            clickable = await page.query_selector_all('[onclick], [role="button"], [role="link"], .cursor-pointer, [class*="click"], [class*="button"]')
            clickable_list = []
            
            for elem in clickable:
                try:
                    tag = await elem.evaluate('el => el.tagName.toLowerCase()')
                    # Skip if already captured as button or link
                    if tag in ['button', 'a', 'input']:
                        continue
                    
                    text = await elem.inner_text() or ''
                    elem_id = await elem.get_attribute('id') or ''
                    elem_class = await elem.get_attribute('class') or ''
                    onclick = await elem.get_attribute('onclick') or ''
                    role = await elem.get_attribute('role') or ''
                    is_visible = await elem.is_visible()
                    
                    if not is_visible:
                        continue
                    
                    clickable_list.append({
                        "text": text.strip()[:100],
                        "tag": tag,
                        "id": elem_id,
                        "class": elem_class,
                        "onclick": onclick,
                        "role": role
                    })
                except:
                    continue
            
            # Create analysis result
            result = {
                "page_info": {
                    "url": current_url,
                    "title": title
                },
                "analysis": {
                    "total_buttons": len(button_list),
                    "total_fields": len(input_list),
                    "total_links": len(link_list),
                    "total_forms": len(form_list),
                    "total_clickable": len(clickable_list),
                    "buttons": button_list,
                    "fields": input_list,
                    "links": link_list,
                    "forms": form_list,
                    "clickable_elements": clickable_list
                }
            }
            
            print(f"\nAnalysis Results:")
            print(f"  Buttons found: {len(button_list)}")
            print(f"  Fields found: {len(input_list)}")
            print(f"  Links found: {len(link_list)}")
            print(f"  Forms found: {len(form_list)}")
            print(f"  Other clickable elements found: {len(clickable_list)}")
            
            # Step 2: Analyze buttons tab-wise
            print(f"\n[Step 2] Analyzing buttons tab-wise...")
            print(f"  Total buttons found: {len(button_elements_map)}")
            
            # Separate buttons into tab buttons and regular buttons
            tab_buttons = []
            regular_buttons = []
            
            for btn_map in button_elements_map:
                btn = btn_map['data']
                if btn.get('is_tab', False):
                    tab_buttons.append(btn_map)
                else:
                    regular_buttons.append(btn_map)
            
            print(f"  Tab buttons: {len(tab_buttons)}")
            print(f"  Regular buttons: {len(regular_buttons)}")
            
            buttons_with_fields = []
            dynamically_found_buttons = []  # Store buttons found during analysis
            
            # Step 2.1: First analyze all regular buttons in the default/initial view
            print(f"\n[Step 2.1] Analyzing regular buttons in default view...")
            for btn_map in regular_buttons:
                btn = btn_map['data']
                btn_element = btn_map['element']
                btn_text = btn.get('text', '')
                btn_type = btn.get('type', '')
                btn_id = btn.get('id', '')
                btn_index = btn.get('index', 0)
                btn_unique_id = btn.get('unique_id', '')
                
                # Show button info including index for duplicates
                button_label = f"'{btn_text}'"
                if not btn_text:
                    button_label = f"[Button {btn_index}]"
                if btn_id:
                    button_label += f" (id: {btn_id})"
                print(f"  [{btn_index + 1}/{len(button_elements_map)}] Analyzing button: {button_label} ({btn_type})")
                
                try:
                    # Reload page to start fresh
                    await page.reload(wait_until='networkidle', timeout=30000)
                    await page.wait_for_timeout(2000)
                    
                    # Try to find the exact button element by index or unique identifier
                    fields_after_click = []
                    clicked = False
                    
                    # Find all buttons and match by position (handles duplicates better)
                    all_buttons = await page.query_selector_all('button, input[type="button"], input[type="submit"], [role="button"]')
                    matching_buttons = []
                    
                    # Get expected position from button data
                    expected_position = btn.get('position', '')
                    
                    # Filter to visible buttons and match by text/type/id AND position
                    for b in all_buttons:
                        try:
                            if not await b.is_visible():
                                continue
                                
                            b_text = await b.inner_text() or await b.get_attribute('value') or ''
                            b_type = await b.get_attribute('type') or 'button'
                            b_id = await b.get_attribute('id') or ''
                            
                            # Match button by text, type, and id
                            if (b_text.strip() == btn_text and 
                                b_type == btn_type and 
                                b_id == btn_id):
                                
                                # Get position to match exact button instance
                                b_box = await b.bounding_box()
                                b_position = f"{b_box['x']:.1f}_{b_box['y']:.1f}" if b_box else ""
                                
                                matching_buttons.append({
                                    'element': b,
                                    'position': b_position,
                                    'matches_position': b_position == expected_position
                                })
                        except:
                            continue
                    
                    # Select button - prefer exact position match, then use index
                    button_elem = None
                    if matching_buttons:
                        # First try to find exact position match
                        position_matches = [mb for mb in matching_buttons if mb['matches_position']]
                        if position_matches:
                            button_elem = position_matches[0]['element']
                        else:
                            # Count how many buttons with same text appear before this one
                            same_text_count = sum(1 for bm in button_elements_map[:btn_index] 
                                                if bm['data'].get('text') == btn_text and 
                                                   bm['data'].get('type') == btn_type and
                                                   bm['data'].get('id') == btn_id)
                            
                            if same_text_count < len(matching_buttons):
                                button_elem = matching_buttons[same_text_count]['element']
                            elif len(matching_buttons) > 0:
                                # Fallback: use first matching button
                                button_elem = matching_buttons[0]['element']
                    
                    if button_elem and await button_elem.is_visible():
                        is_tab_button = btn.get('is_tab', False)
                        
                        if is_tab_button:
                            print(f"    -> Clicking TAB button, switching to tab view...")
                        else:
                            print(f"    -> Clicking button...")
                        
                        await button_elem.click()
                        # Wait for tab/content to load and dynamic content to appear
                        await page.wait_for_timeout(2000)
                        # Wait for any tab transitions or content loading
                        try:
                            await page.wait_for_load_state('networkidle', timeout=5000)
                        except:
                            pass
                        clicked = True
                        
                        if is_tab_button:
                            print(f"    -> Tab switched, analyzing tab content (fields and buttons)...")
                        else:
                            print(f"    -> Button clicked, analyzing content...")
                        
                        # Get all fields in the current tab/view
                        fields_after_click = await get_fields_in_visual_order(page)
                        if is_tab_button:
                            print(f"    -> Found {len(fields_after_click)} fields in this TAB")
                        else:
                            print(f"    -> Found {len(fields_after_click)} fields after clicking")
                        
                        # IMPORTANT: Check for NEW buttons that appeared after clicking (in this tab)
                        print(f"    -> Checking for buttons in this tab/view...")
                        new_buttons_after_click = await page.query_selector_all(
                            'button:visible, input[type="button"]:visible, input[type="submit"]:visible, [role="button"]:visible'
                        )
                        print(f"    -> Found {len(new_buttons_after_click)} buttons in this tab/view")
                        
                        # Get buttons that appeared after click (not in original list)
                        original_button_texts = {b['data'].get('text', '').strip() for b in button_elements_map}
                        dynamically_appeared_buttons = []
                        
                        for new_btn in new_buttons_after_click:
                            try:
                                new_btn_text = (await new_btn.inner_text() or await new_btn.get_attribute('value') or '').strip()
                                new_btn_id = await new_btn.get_attribute('id') or ''
                                new_btn_type = await new_btn.get_attribute('type') or 'button'
                                new_btn_tag = await new_btn.evaluate('el => el.tagName.toLowerCase()')
                                
                                # Check if this is a new button (not in original list)
                                is_new_button = True
                                for orig_btn in button_elements_map:
                                    orig_text = orig_btn['data'].get('text', '').strip()
                                    orig_id = orig_btn['data'].get('id', '')
                                    if new_btn_text == orig_text and new_btn_id == orig_id:
                                        is_new_button = False
                                        break
                                
                                if is_new_button and new_btn_text:
                                    box = await new_btn.bounding_box()
                                    position_key = f"{box['x']:.1f}_{box['y']:.1f}" if box else f"pos_dynamic_{len(dynamically_appeared_buttons)}"
                                    
                                    # Get form info if any
                                    form_info = None
                                    if new_btn_type == 'submit' or new_btn_tag == 'button':
                                        try:
                                            form_info = await new_btn.evaluate('''el => {
                                                let parent = el.closest('form');
                                                if (parent) {
                                                    return {
                                                        id: parent.id || '',
                                                        action: parent.action || '',
                                                        method: parent.method || 'get'
                                                    };
                                                }
                                                return null;
                                            }''')
                                        except:
                                            pass
                                    
                                    # Create unique element_id for dynamic button
                                    try:
                                        dynamic_element_unique = await new_btn.evaluate('''el => {
                                            const rect = el.getBoundingClientRect();
                                            return {
                                                html: el.outerHTML.substring(0, 50),
                                                x: Math.round(rect.x),
                                                y: Math.round(rect.y),
                                                id: el.id || '',
                                                text: (el.innerText || el.value || '').substring(0, 50),
                                                index: Array.from(el.parentElement?.children || []).indexOf(el)
                                            };
                                        }''')
                                        dynamic_element_id = f"{dynamic_element_unique['html']}_{dynamic_element_unique['x']}_{dynamic_element_unique['y']}_{dynamic_element_unique['id']}_{dynamic_element_unique['text']}_{dynamic_element_unique['index']}"
                                    except:
                                        dynamic_element_id = f"{new_btn_id}_{new_btn_text}_{position_key}"
                                    
                                    new_btn_data = {
                                        "text": new_btn_text,
                                        "type": new_btn_type,
                                        "id": new_btn_id,
                                        "class": await new_btn.get_attribute('class') or '',
                                        "tag": new_btn_tag,
                                        "form": form_info,
                                        "position": position_key,
                                        "index": len(button_list) + len(dynamically_appeared_buttons),
                                        "unique_id": f"btn_dynamic_{len(dynamically_appeared_buttons)}_{position_key}_{dynamic_element_id[:20]}",
                                        "element_id": dynamic_element_id,  # Store for duplicate checking
                                        "appeared_after_clicking": btn_text  # Track which button triggered this
                                    }
                                    
                                    dynamically_appeared_buttons.append({
                                        'data': new_btn_data,
                                        'element': new_btn
                                    })
                                    
                                    print(f"      -> Found new button: '{new_btn_text}' (appeared after clicking '{btn_text}')")
                            except:
                                continue
                        
                        # Add dynamically appeared buttons to the list for analysis (ONCE - will be analyzed in Step 2.5)
                        if dynamically_appeared_buttons:
                            print(f"    -> Found {len(dynamically_appeared_buttons)} new buttons after clicking")
                            # Store for analysis after main loop (Step 2.5) - DO NOT analyze immediately
                            # Check for duplicates before adding
                            for new_btn_map in dynamically_appeared_buttons:
                                new_btn_data = new_btn_map['data']
                                new_btn_text = new_btn_data.get('text', '')
                                new_btn_id = new_btn_data.get('id', '')
                                new_btn_position = new_btn_data.get('position', '')
                                
                                # Check if this button is already in button_list or dynamically_found_buttons
                                # Use element_id for more accurate duplicate detection
                                new_element_id = new_btn_data.get('element_id', '')
                                is_duplicate = False
                                
                                for existing_btn in button_list:
                                    existing_element_id = existing_btn.get('element_id', '')
                                    # If element_id matches, it's the same DOM element
                                    if existing_element_id and new_element_id and existing_element_id == new_element_id:
                                        is_duplicate = True
                                        break
                                    # Fallback: check text, id, and position
                                    existing_text = existing_btn.get('text', '').strip()
                                    existing_id = existing_btn.get('id', '')
                                    existing_pos = existing_btn.get('position', '')
                                    if (existing_text == new_btn_text.strip() and 
                                        existing_id == new_btn_id and
                                        existing_pos == new_btn_position):
                                        is_duplicate = True
                                        break
                                
                                for existing_dynamic in dynamically_found_buttons:
                                    existing_data = existing_dynamic.get('data', {})
                                    existing_element_id = existing_data.get('element_id', '')
                                    # If element_id matches, it's the same DOM element
                                    if existing_element_id and new_element_id and existing_element_id == new_element_id:
                                        is_duplicate = True
                                        break
                                    # Fallback: check text, id, and position
                                    existing_text = existing_data.get('text', '').strip()
                                    existing_id = existing_data.get('id', '')
                                    existing_pos = existing_data.get('position', '')
                                    if (existing_text == new_btn_text.strip() and 
                                        existing_id == new_btn_id and
                                        existing_pos == new_btn_position):
                                        is_duplicate = True
                                        break
                                
                                if not is_duplicate:
                                    dynamically_found_buttons.append(new_btn_map)
                                    button_list.append(new_btn_data)
                                    print(f"      -> Added unique new button: '{new_btn_text}' (will analyze in Step 2.5)")
                                else:
                                    print(f"      -> Skipped duplicate button: '{new_btn_text}'")
                        
                        # Fields were already captured above, but ensure we have them
                        if not fields_after_click:
                            fields_after_click = await get_fields_in_visual_order(page)
                            print(f"    -> Re-checked: Found {len(fields_after_click)} fields in this tab/view")
                        
                        # Also check for fields that might have appeared in the same container/form
                        if len(fields_after_click) == 0:
                            print(f"    -> No fields found after click, checking page for any new fields...")
                            # Re-scan the entire page for any new fields
                            all_fields_now = await get_fields_in_visual_order(page)
                            if all_fields_now:
                                fields_after_click = all_fields_now
                                print(f"    -> Found {len(fields_after_click)} total fields on page after click")
                        
                        # Also check if button is in a form and get form fields
                        form_fields = []
                        if button_elem:
                            try:
                                # Get form element using evaluate (returns element or null)
                                form_element = await button_elem.evaluate('el => el.closest("form")')
                                if form_element:
                                    # Use the page to query within the form
                                    form_selector = await button_elem.evaluate('''el => {
                                        const form = el.closest("form");
                                        if (form && form.id) return `form#${form.id}`;
                                        if (form && form.className) return `form.${form.className.split(' ')[0]}`;
                                        return 'form';
                                    }''')
                                    form_inputs = await page.query_selector_all(f'{form_selector} input, {form_selector} textarea, {form_selector} select')
                                    for inp in form_inputs:
                                        try:
                                            inp_name = await inp.get_attribute('name') or ''
                                            inp_id = await inp.get_attribute('id') or ''
                                            inp_type = await inp.get_attribute('type') or 'text'
                                            placeholder = await inp.get_attribute('placeholder') or ''
                                            is_visible = await inp.is_visible()
                                            
                                            if (inp_name or inp_id) and is_visible:
                                                form_fields.append({
                                                    'name': inp_name,
                                                    'type': inp_type,
                                                    'id': inp_id,
                                                    'placeholder': placeholder
                                                })
                                        except:
                                            continue
                            except Exception as e:
                                print(f"    -> Error getting form fields: {e}")
                    
                    # Use fields_after_click if available, otherwise use form_fields
                    final_fields = fields_after_click if fields_after_click else form_fields
                    
                    buttons_with_fields.append({
                        "button": btn,
                        "fields": final_fields,
                        "field_count": len(final_fields),
                        "clicked": clicked,
                        "button_index": btn_index,
                        "unique_id": btn_unique_id
                    })
                    
                except Exception as e:
                    print(f"    -> Error: {e}")
                    buttons_with_fields.append({
                        "button": btn,
                        "fields": [],
                        "field_count": 0,
                        "clicked": False,
                        "button_index": btn_index,
                        "unique_id": btn_unique_id
                    })
            
            # Step 2.2: Analyze buttons tab-wise
            print(f"\n[Step 2.2] Analyzing buttons in each tab...")
            print(f"  Found {len(tab_buttons)} tab buttons to analyze")
            
            for tab_idx, tab_btn_map in enumerate(tab_buttons):
                tab_btn = tab_btn_map['data']
                tab_btn_text = tab_btn.get('text', '')
                tab_btn_id = tab_btn.get('id', '')
                tab_btn_unique_id = tab_btn.get('unique_id', '')
                
                print(f"\n  [{tab_idx + 1}/{len(tab_buttons)}] Analyzing TAB: '{tab_btn_text}'")
                
                try:
                    # Reload page to start fresh
                    await page.reload(wait_until='networkidle', timeout=30000)
                    await page.wait_for_timeout(2000)
                    
                    # Find and click the tab button
                    tab_button_elem = None
                    all_buttons = await page.query_selector_all('button, input[type="button"], input[type="submit"], [role="button"], [role="tab"]')
                    
                    for b in all_buttons:
                        try:
                            if not await b.is_visible():
                                continue
                            b_text = (await b.inner_text() or await b.get_attribute('value') or '').strip()
                            b_id = await b.get_attribute('id') or ''
                            if (b_text == tab_btn_text and b_id == tab_btn_id):
                                tab_button_elem = b
                                break
                        except:
                            continue
                    
                    if tab_button_elem:
                        print(f"    -> Clicking tab button '{tab_btn_text}'...")
                        await tab_button_elem.click()
                        await page.wait_for_timeout(2000)
                        try:
                            await page.wait_for_load_state('networkidle', timeout=5000)
                        except:
                            pass
                        
                        # Analyze the tab button itself (it was clicked)
                        tab_fields = await get_fields_in_visual_order(page)
                        print(f"    -> Found {len(tab_fields)} fields in tab '{tab_btn_text}'")
                        
                        # Check if tab button was already analyzed
                        tab_already_analyzed = False
                        for existing in buttons_with_fields:
                            existing_btn = existing.get('button', {})
                            if (existing_btn.get('text', '').strip() == tab_btn_text and 
                                existing_btn.get('id', '') == tab_btn_id and
                                existing.get('unique_id') == tab_btn_unique_id):
                                tab_already_analyzed = True
                                break
                        
                        if not tab_already_analyzed:
                            buttons_with_fields.append({
                                "button": tab_btn,
                                "fields": tab_fields,
                                "field_count": len(tab_fields),
                                "clicked": True,
                                "button_index": tab_btn.get('index', 0),
                                "unique_id": tab_btn_unique_id,
                                "is_tab": True,
                                "tab_name": tab_btn_text
                            })
                        
                        # Now find all buttons in this tab view
                        print(f"    -> Finding buttons in tab '{tab_btn_text}'...")
                        tab_view_buttons = await page.query_selector_all(
                            'button:visible, input[type="button"]:visible, input[type="submit"]:visible, [role="button"]:visible'
                        )
                        print(f"    -> Found {len(tab_view_buttons)} buttons in tab '{tab_btn_text}'")
                        
                        # Analyze each button in this tab
                        for tab_view_btn in tab_view_buttons:
                            try:
                                tv_btn_text = (await tab_view_btn.inner_text() or await tab_view_btn.get_attribute('value') or '').strip()
                                tv_btn_id = await tab_view_btn.get_attribute('id') or ''
                                tv_btn_type = await tab_view_btn.get_attribute('type') or 'button'
                                
                                # Skip if this is the tab button itself (already analyzed)
                                if tv_btn_text == tab_btn_text and tv_btn_id == tab_btn_id:
                                    continue
                                
                                # Check if this button was already analyzed
                                already_analyzed = False
                                for existing in buttons_with_fields:
                                    existing_btn = existing.get('button', {})
                                    if (existing_btn.get('text', '').strip() == tv_btn_text and 
                                        existing_btn.get('id', '') == tv_btn_id):
                                        already_analyzed = True
                                        break
                                
                                if already_analyzed:
                                    print(f"      -> Skipping already analyzed button: '{tv_btn_text}'")
                                    continue
                                
                                print(f"      -> Analyzing button in tab: '{tv_btn_text}'")
                                
                                # Click the button to see its fields
                                await tab_view_btn.click()
                                await page.wait_for_timeout(1500)
                                try:
                                    await page.wait_for_load_state('networkidle', timeout=3000)
                                except:
                                    pass
                                
                                # Get fields after clicking
                                tv_btn_fields = await get_fields_in_visual_order(page)
                                print(f"        -> Found {len(tv_btn_fields)} fields for button '{tv_btn_text}'")
                                
                                # Get button properties
                                box = await tab_view_btn.bounding_box()
                                position_key = f"{box['x']:.1f}_{box['y']:.1f}" if box else f"pos_tab_{tab_idx}"
                                
                                tv_btn_data = {
                                    "text": tv_btn_text,
                                    "type": tv_btn_type,
                                    "id": tv_btn_id,
                                    "class": await tab_view_btn.get_attribute('class') or '',
                                    "tag": await tab_view_btn.evaluate('el => el.tagName.toLowerCase()'),
                                    "position": position_key,
                                    "index": len(button_list) + len(buttons_with_fields),
                                    "unique_id": f"btn_tab_{tab_idx}_{tv_btn_id}_{position_key}",
                                    "in_tab": tab_btn_text
                                }
                                
                                buttons_with_fields.append({
                                    "button": tv_btn_data,
                                    "fields": tv_btn_fields,
                                    "field_count": len(tv_btn_fields),
                                    "clicked": True,
                                    "button_index": tv_btn_data.get('index', 0),
                                    "unique_id": tv_btn_data.get('unique_id', ''),
                                    "is_tab": False,
                                    "in_tab": tab_btn_text
                                })
                                
                            except Exception as e:
                                print(f"        -> Error analyzing button in tab: {e}")
                                continue
                    else:
                        print(f"    -> Tab button '{tab_btn_text}' not found on page")
                        # Check if already analyzed
                        tab_already_analyzed = False
                        for existing in buttons_with_fields:
                            existing_btn = existing.get('button', {})
                            if (existing_btn.get('text', '').strip() == tab_btn_text and 
                                existing_btn.get('id', '') == tab_btn_id and
                                existing.get('unique_id') == tab_btn_unique_id):
                                tab_already_analyzed = True
                                break
                        
                        if not tab_already_analyzed:
                            buttons_with_fields.append({
                                "button": tab_btn,
                                "fields": [],
                                "field_count": 0,
                                "clicked": False,
                                "button_index": tab_btn.get('index', 0),
                                "unique_id": tab_btn_unique_id,
                                "is_tab": True,
                                "tab_name": tab_btn_text
                            })
                except Exception as e:
                    print(f"    -> Error analyzing tab '{tab_btn_text}': {e}")
                    # Check if already analyzed
                    tab_already_analyzed = False
                    for existing in buttons_with_fields:
                        existing_btn = existing.get('button', {})
                        if (existing_btn.get('text', '').strip() == tab_btn_text and 
                            existing_btn.get('id', '') == tab_btn_id and
                            existing.get('unique_id') == tab_btn_unique_id):
                            tab_already_analyzed = True
                            break
                    
                    if not tab_already_analyzed:
                        buttons_with_fields.append({
                            "button": tab_btn,
                            "fields": [],
                            "field_count": 0,
                            "clicked": False,
                            "button_index": tab_btn.get('index', 0),
                            "unique_id": tab_btn_unique_id,
                            "is_tab": True,
                            "tab_name": tab_btn_text
                        })
            
            # Step 2.5: Analyze dynamically appeared buttons
            if dynamically_found_buttons:
                print(f"\n[Step 2.5] Analyzing {len(dynamically_found_buttons)} dynamically appeared buttons...")
                for btn_map in dynamically_found_buttons:
                    btn = btn_map['data']
                    btn_text = btn.get('text', '')
                    btn_type = btn.get('type', '')
                    btn_id = btn.get('id', '')
                    btn_index = btn.get('index', 0)
                    btn_unique_id = btn.get('unique_id', '')
                    triggered_by = btn.get('appeared_after_clicking', '')
                    
                    print(f"  Analyzing dynamic button: '{btn_text}' (appeared after '{triggered_by}')")
                    
                    try:
                        # Reload page and click the trigger button first, then analyze the new button
                        await page.reload(wait_until='networkidle', timeout=30000)
                        await page.wait_for_timeout(2000)
                        
                        # Find and click the trigger button first
                        if triggered_by:
                            trigger_buttons = await page.query_selector_all('button, input[type="button"], input[type="submit"]')
                            for trigger_btn in trigger_buttons:
                                try:
                                    trigger_text = (await trigger_btn.inner_text() or await trigger_btn.get_attribute('value') or '').strip()
                                    if trigger_text == triggered_by and await trigger_btn.is_visible():
                                        await trigger_btn.click()
                                        await page.wait_for_timeout(2000)
                                        break
                                except:
                                    continue
                        
                        # Now find and click the dynamic button
                        dynamic_btn_elem = None
                        all_buttons_after = await page.query_selector_all('button:visible, input[type="button"]:visible, input[type="submit"]:visible')
                        
                        for b in all_buttons_after:
                            try:
                                b_text = (await b.inner_text() or await b.get_attribute('value') or '').strip()
                                b_id = await b.get_attribute('id') or ''
                                if b_text == btn_text and b_id == btn_id:
                                    dynamic_btn_elem = b
                                    break
                            except:
                                continue
                        
                        fields_after_click = []
                        clicked = False
                        
                        if dynamic_btn_elem:
                            await dynamic_btn_elem.click()
                            await page.wait_for_timeout(2000)
                            clicked = True
                            fields_after_click = await get_fields_in_visual_order(page)
                            print(f"    -> Found {len(fields_after_click)} fields after clicking dynamic button")
                            
                            # Check for buttons that appeared after clicking this dynamic button
                            nested_buttons = await page.query_selector_all(
                                'button:visible, input[type="button"]:visible, input[type="submit"]:visible'
                            )
                            nested_button_count = 0
                            for nested_btn in nested_buttons:
                                try:
                                    nested_text = (await nested_btn.inner_text() or await nested_btn.get_attribute('value') or '').strip()
                                    # Check if this is a new button we haven't seen
                                    is_new = True
                                    for existing_btn_data in button_list:
                                        if existing_btn_data.get('text', '').strip() == nested_text:
                                            is_new = False
                                            break
                                    if is_new and nested_text:
                                        nested_button_count += 1
                                        print(f"      -> Found nested button: '{nested_text}' (appeared after clicking '{btn_text}')")
                                except:
                                    continue
                            
                            if nested_button_count > 0:
                                print(f"    -> Found {nested_button_count} additional buttons after clicking dynamic button")
                        
                        # Check if this button was already analyzed in main loop
                        already_analyzed = False
                        for existing in buttons_with_fields:
                            existing_btn = existing.get('button', {})
                            existing_unique_id = existing.get('unique_id', '')
                            if (existing_btn.get('text', '').strip() == btn_text.strip() and 
                                existing_btn.get('id', '') == btn_id and
                                existing_unique_id == btn_unique_id):
                                already_analyzed = True
                                break
                        
                        if not already_analyzed:
                            buttons_with_fields.append({
                                "button": btn,
                                "fields": fields_after_click,
                                "field_count": len(fields_after_click),
                                "clicked": clicked,
                                "button_index": btn_index,
                                "unique_id": btn_unique_id,
                                "is_dynamic": True,
                                "triggered_by": triggered_by
                            })
                        else:
                            print(f"    -> Skipped duplicate analysis for dynamic button: '{btn_text}'")
                    except Exception as e:
                        print(f"    -> Error analyzing dynamic button: {e}")
                        # Check if already analyzed before adding error entry
                        already_analyzed = False
                        for existing in buttons_with_fields:
                            existing_btn = existing.get('button', {})
                            existing_unique_id = existing.get('unique_id', '')
                            if (existing_btn.get('text', '').strip() == btn_text.strip() and 
                                existing_btn.get('id', '') == btn_id and
                                existing_unique_id == btn_unique_id):
                                already_analyzed = True
                                break
                        
                        if not already_analyzed:
                            buttons_with_fields.append({
                                "button": btn,
                                "fields": [],
                                "field_count": 0,
                                "clicked": False,
                                "button_index": btn_index,
                                "unique_id": btn_unique_id,
                                "is_dynamic": True,
                                "triggered_by": triggered_by
                            })
            
            # Step 3: Analyze links (check if they have associated fields/forms)
            print(f"\n[Step 3] Analyzing links and other elements...")
            links_with_fields = []
            
            for link in link_list:
                try:
                    # Check if link is near any form or fields
                    link_href = link.get('href', '')
                    link_text = link.get('text', '')
                    
                    # Try to find form near this link
                    await page.reload(wait_until='networkidle', timeout=30000)
                    await page.wait_for_timeout(2000)
                    
                    link_elem = None
                    if link.get('id'):
                        link_elem = await page.query_selector(f"a#{link['id']}")
                    elif link_text:
                        link_elem = await page.query_selector(f"a:has-text('{link_text}')")
                    
                    nearby_fields = []
                    if link_elem:
                        # Check for fields in same container or nearby
                        # Get parent container
                        parent_info = await link_elem.evaluate('''el => {
                            const parent = el.closest("form, div, section");
                            if (parent) {
                                if (parent.id) return { type: parent.tagName.toLowerCase(), id: parent.id, selector: `${parent.tagName.toLowerCase()}#${parent.id}` };
                                if (parent.className) return { type: parent.tagName.toLowerCase(), className: parent.className.split(' ')[0], selector: `${parent.tagName.toLowerCase()}.${parent.className.split(' ')[0]}` };
                                return { type: parent.tagName.toLowerCase(), selector: parent.tagName.toLowerCase() };
                            }
                            return null;
                        }''')
                        if parent_info:
                            nearby_inputs = await page.query_selector_all(f'{parent_info["selector"]} input, {parent_info["selector"]} textarea, {parent_info["selector"]} select')
                            for inp in nearby_inputs:
                                try:
                                    if await inp.is_visible():
                                        inp_name = await inp.get_attribute('name') or ''
                                        inp_id = await inp.get_attribute('id') or ''
                                        if inp_name or inp_id:
                                            nearby_fields.append({
                                                'name': inp_name,
                                                'type': await inp.get_attribute('type') or 'text',
                                                'id': inp_id
                                            })
                                except:
                                    continue
                    
                    links_with_fields.append({
                        "link": link,
                        "fields": nearby_fields,
                        "field_count": len(nearby_fields)
                    })
                except:
                    links_with_fields.append({
                        "link": link,
                        "fields": [],
                        "field_count": 0
                    })
            
            # Step 4: Analyze clickable elements
            print(f"\n[Step 4] Analyzing clickable elements...")
            clickable_with_fields = []
            
            for click_elem in clickable_list:
                try:
                    # Similar analysis for clickable elements
                    clickable_with_fields.append({
                        "element": click_elem,
                        "fields": [],  # Can be extended if needed
                        "field_count": 0
                    })
                except:
                    clickable_with_fields.append({
                        "element": click_elem,
                        "fields": [],
                        "field_count": 0
                    })
            
            # Create final result
            result = {
                "page_info": {
                    "url": current_url,
                    "title": title
                },
                "analysis": {
                    "total_buttons": len(button_list),
                    "total_fields": len(input_list),
                    "total_links": len(link_list),
                    "total_forms": len(form_list),
                    "total_clickable": len(clickable_list),
                    "buttons": button_list,
                    "fields": input_list,
                    "links": link_list,
                    "forms": form_list,
                    "clickable_elements": clickable_list,
                    "buttons_with_fields": buttons_with_fields,
                    "links_with_fields": links_with_fields,
                    "clickable_with_fields": clickable_with_fields
                }
            }
            
            print(f"\nFinal Analysis:")
            print(f"  Total Buttons: {len(button_list)}")
            print(f"  Total Fields: {len(input_list)}")
            print(f"  Total Links: {len(link_list)}")
            print(f"  Total Forms: {len(form_list)}")
            print(f"  Total Clickable Elements: {len(clickable_list)}")
            print(f"\nButtons with Fields:")
            for btn_data in buttons_with_fields:
                btn = btn_data['button']
                fields = btn_data['fields']
                print(f"    '{btn['text']}' - {len(fields)} fields")
                for field in fields[:3]:  # Show first 3 fields
                    print(f"      - {field['name']} ({field['type']})")
                if len(fields) > 3:
                    print(f"      ... and {len(fields) - 3} more")
            print(f"\nLinks with Fields:")
            for link_data in links_with_fields:
                link = link_data['link']
                fields = link_data['fields']
                if fields:
                    print(f"    '{link['text']}' ({link['href']}) - {len(fields)} fields")
            
            return result
            
        finally:
            await browser.close()


async def main():
    """Main entry point for Agent 1."""
    if len(sys.argv) < 2:
        print("Usage: python analyze.py <URL> [--show]")
        print("Example: python analyze.py https://example.com")
        print("         python analyze.py https://example.com --show")
        sys.exit(1)
    
    url = sys.argv[1]
    headless = '--show' not in sys.argv
    
    try:
        # Analyze page
        result = await analyze_page(url, headless=headless)
        
        # Save to versioned JSON file
        version_manager = VersionManager()
        filepath = version_manager.save_json("analyze", result)
        
        print(f"\n[SUCCESS] Analysis saved to: {filepath}")
        print(f"\nNext steps:")
        print(f"   1. Review {filepath.name}")
        print(f"   2. Run: python detect.py")
        
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

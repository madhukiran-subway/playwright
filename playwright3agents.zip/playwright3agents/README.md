# Playwright 3-Agent Automation System

An AI-powered browser automation system that uses three specialized agents to analyze web pages, generate Playwright scripts, and execute tests with full human oversight.

## 🏗️ Architecture

The system consists of three sequential agents:

1. **Agent 1 (analyze.py)**: Analyzes web page structure and UI elements
2. **Agent 2 (script.py)**: Generates Playwright automation scripts
3. **Agent 3 (testresult.py)**: Executes tests and generates HTML reports

## 📋 Prerequisites

- Python 3.8+
- OpenAI API key
- Node.js (for Playwright)

## 🚀 Installation

1. **Clone or navigate to the project directory**

2. **Install Python dependencies:**
```bash
pip install -r requirements.txt
```

3. **Install Playwright browsers:**
```bash
playwright install chromium
```

4. **Set up environment variables:**
```bash
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY
```

## 📖 Usage

### Step 1: Analyze a Web Page (Agent 1)

Analyze the structure and UI elements of a web page:

```bash
python analyze.py https://example.com
```

This will:
- Fetch the web page content
- Use OpenAI API to analyze UI elements (buttons, links, inputs, etc.)
- Save results to `output/analyze1.json` (versioned)

**Output:** `output/analyze1.json`, `output/analyze2.json`, etc.

### Step 2: Review Analysis (Manual Verification)

Before proceeding, review the generated analysis file:

```bash
# Review the latest analysis
cat output/analyze1.json
```

Verify that:
- All important UI elements are identified
- Selectors are appropriate
- Element descriptions are accurate

### Step 3: Generate Playwright Script (Agent 2)

Generate a Playwright automation script from the analysis:

```bash
# Use latest analysis (default)
python script.py

# Or specify a specific analysis version
python script.py 1
```

This will:
- Load the analysis JSON
- Use OpenAI API to generate Playwright code
- Save results to `output/script1.json` (versioned)

**Output:** `output/script1.json`, `output/script2.json`, etc.

### Step 4: Review Script (Manual Verification)

Before executing, review the generated script:

```bash
# Review the latest script
cat output/script1.json
```

Verify that:
- Selectors match the analyzed elements
- Actions are appropriate
- The script logic is correct

### Step 5: Execute Test (Agent 3)

Execute the Playwright test and generate a report:

```bash
# Use latest script (default)
python testresult.py

# Or specify a specific script version
python testresult.py 1
```

This will:
- Load the script JSON
- Execute the Playwright test
- Generate an HTML report
- Save results to `output/report1.html` (versioned)

**Output:** `output/report1.html`, `output/report2.html`, etc.

## 📁 Project Structure

```
playwright3agents/
├── analyze.py              # Agent 1: Page analyzer
├── script.py               # Agent 2: Script generator
├── testresult.py           # Agent 3: Test executor
├── utils/
│   ├── version_manager.py  # Version management for outputs
│   ├── config.py           # Configuration loader
│   └── page_analyzer.py     # Web page fetching utility
├── output/                 # Generated files (created automatically)
│   ├── analyze1.json
│   ├── script1.json
│   └── report1.html
├── requirements.txt        # Python dependencies
├── .env.example           # Environment variables template
└── README.md              # This file
```

## 🔧 Configuration

### Environment Variables

Create a `.env` file with:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4o  # Optional, defaults to gpt-4o
```

### Version Management

All outputs are automatically versioned:
- Analysis files: `analyze1.json`, `analyze2.json`, ...
- Script files: `script1.json`, `script2.json`, ...
- Reports: `report1.html`, `report2.html`, ...

The system automatically increments version numbers.

## 🎯 Workflow Example

```bash
# 1. Analyze a page
python analyze.py https://example.com/login

# 2. Review output/analyze1.json (manual step)

# 3. Generate script
python script.py

# 4. Review output/script1.json (manual step)

# 5. Execute test
python testresult.py

# 6. Open output/report1.html in browser to view results
```

## 🔍 Features

- **Versioned Outputs**: All outputs are automatically versioned
- **Human Oversight**: Manual verification steps between agents
- **AI-Powered**: Uses OpenAI API and LangChain for intelligent analysis and generation
- **Comprehensive Reports**: Beautiful HTML reports with test results
- **Error Handling**: Robust error handling and reporting

## ⚠️ Important Notes

1. **Agent 1** only analyzes - it does NOT generate scripts
2. **Agent 2** only generates code - it does NOT execute tests
3. **Agent 3** executes tests and generates reports
4. Always review outputs between steps for accuracy
5. Ensure your OpenAI API key has sufficient credits

## 🐛 Troubleshooting

### OpenAI API Errors
- Verify your API key in `.env`
- Check your API quota/credits
- Ensure you have access to the specified model

### Playwright Errors
- Run `playwright install chromium` to install browsers
- Check that the script selectors are correct
- Review the HTML report for detailed error messages

### Import Errors
- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Check that you're using Python 3.8+

## 📝 License

This project is provided as-is for automation and testing purposes.


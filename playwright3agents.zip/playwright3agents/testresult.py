"""
Agent 3: Test Executor

Executes Playwright tests from script JSON and generates HTML reports.
Outputs versioned HTML reports (report1.html, report2.html, etc.).
"""
import asyncio
import json
import sys
import tempfile
import os
import re
from pathlib import Path
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
from utils.config import Config
from utils.version_manager import VersionManager
from datetime import datetime


async def execute_playwright_script(script_data: dict) -> dict:
    """
    Execute Playwright script and collect results.
    Tests the script against the live website URL.
    
    Args:
        script_data: Dictionary containing Playwright script from Agent 2
        
    Returns:
        Dictionary containing test execution results
    """
    print(f"\n[Agent 3] Executing Playwright test against live website")
    print("=" * 60)
    
    # Extract URL from script data or script code
    url = None
    if "metadata" in script_data and "url" in script_data["metadata"]:
        url = script_data["metadata"]["url"]
    elif "description" in script_data:
        # Try to extract URL from description
        import re
        url_match = re.search(r'https?://[^\s]+', script_data["description"])
        if url_match:
            url = url_match.group(0)
    
    # Extract URL from script code
    script_code = script_data.get("script", "")
    script_lines = script_data.get("script_lines", [])
    
    if not url:
        # Try to find URL in script code
        import re
        if script_lines:
            for line in script_lines:
                url_match = re.search(r"goto\(['\"](https?://[^'\"]+)['\"]\)", line)
                if url_match:
                    url = url_match.group(1)
                    break
        elif script_code:
            url_match = re.search(r"goto\(['\"](https?://[^'\"]+)['\"]\)", script_code)
            if url_match:
                url = url_match.group(1)
    
    if url:
        print(f"[Testing] Website URL: {url}")
    else:
        print(f"[WARNING] Could not extract URL from script data")
    
    print(f"[Executing] Playwright script against live website...")
    
    if not script_code and not script_lines:
        raise ValueError("No script code found in script data")
    
    # Use script_lines if available, otherwise split script
    if script_lines:
        lines = script_lines
    else:
        lines = script_code.split('\n')
    
    # Check if it's already a complete Python script (has async def or if __name__)
    is_complete_script = any('async def' in line or 'if __name__' in line for line in lines)
    
    if is_complete_script:
        # Script is already complete, wrap it to capture results
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
            # Read the original script and modify it to return results
            script_content = "\n".join(lines)
            
            # If the script already has run_test(), wrap it
            if 'async def run_test()' in script_content:
                # Replace the original run_test to add result tracking
                modified_script = script_content.replace(
                    'if __name__ == \'__main__\':\n    asyncio.run(run_test())',
                    '''async def run_test_with_results():
    test_results = {
        "passed": [],
        "failed": [],
        "errors": [],
        "steps": []
    }
    
    try:
        await run_test()
        test_results["passed"].append("Test completed successfully")
    except Exception as e:
        error_msg = f"Test failed: {str(e)}"
        test_results["failed"].append(error_msg)
        test_results["errors"].append({
            "type": type(e).__name__,
            "message": str(e),
            "traceback": str(e)
        })
        import traceback
        test_results["traceback"] = traceback.format_exc()
    
    return test_results

if __name__ == '__main__':
    results = asyncio.run(run_test_with_results())
    print(json.dumps(results))'''
                )
                # Add json import if not present
                if 'import json' not in modified_script:
                    modified_script = modified_script.replace('import asyncio', 'import asyncio\nimport json')
            else:
                # Fallback: wrap entire script
                modified_script = f"""import asyncio
import sys
import json

{script_content}

# Wrap in test execution
async def run_test_with_results():
    test_results = {{
        "passed": [],
        "failed": [],
        "errors": [],
        "steps": []
    }}
    
    try:
        await run_test()
        test_results["passed"].append("Test completed successfully")
    except Exception as e:
        error_msg = f"Test failed: {{str(e)}}"
        test_results["failed"].append(error_msg)
        test_results["errors"].append({{
            "type": type(e).__name__,
            "message": str(e),
            "traceback": str(e)
        }})
        import traceback
        test_results["traceback"] = traceback.format_exc()
    
    return test_results

if __name__ == "__main__":
    results = asyncio.run(run_test_with_results())
    print(json.dumps(results))
"""
            f.write(modified_script)
            temp_file = f.name
    else:
        # Script needs to be wrapped in test structure
        if not script_code:
            raise ValueError("No script code found in script data")
        
        # Create temporary Python file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
            # Wrap script in proper test structure
            test_code = f"""import asyncio
from playwright.async_api import async_playwright
import sys
import json

async def run_test():
    playwright = await async_playwright().start()
    browser = await playwright.chromium.launch(headless=True)
    context = await browser.new_context()
    page = await context.new_page()
    
    test_results = {{
        "passed": [],
        "failed": [],
        "errors": [],
        "steps": []
    }}
    
    try:
{chr(10).join('        ' + line for line in script_code.split(chr(10)) if line.strip())}
        test_results["passed"].append("Test completed successfully")
    except Exception as e:
        error_msg = f"Test failed: {{str(e)}}"
        test_results["failed"].append(error_msg)
        test_results["errors"].append({{
            "type": type(e).__name__,
            "message": str(e),
            "traceback": str(e)
        }})
        import traceback
        test_results["traceback"] = traceback.format_exc()
    finally:
        await browser.close()
        await playwright.stop()
    
    return test_results

if __name__ == "__main__":
    results = asyncio.run(run_test())
    print(json.dumps(results))
"""
            f.write(test_code)
            temp_file = f.name
    
    try:
        if url:
            print(f"[Info] Script will test against: {url}")
        print(f"[Executing] Running Playwright script...")
        
        # Execute the script - this will test against the live website
        process = await asyncio.create_subprocess_exec(
            sys.executable, temp_file,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        # Parse results
        if stdout:
            try:
                results = json.loads(stdout.decode('utf-8'))
            except json.JSONDecodeError:
                results = {
                    "passed": [],
                    "failed": ["Could not parse test results"],
                    "errors": [{"message": stdout.decode('utf-8')}],
                    "output": stdout.decode('utf-8')
                }
        else:
            results = {
                "passed": [],
                "failed": ["No output from test"],
                "errors": []
            }
        
        if stderr:
            error_output = stderr.decode('utf-8')
            if error_output.strip():
                if "errors" not in results:
                    results["errors"] = []
                results["errors"].append({
                    "type": "ExecutionError",
                    "message": error_output
                })
        
        results["exit_code"] = process.returncode
        results["success"] = process.returncode == 0 and len(results.get("failed", [])) == 0
        
        return results
        
    finally:
        # Clean up temporary file
        try:
            os.unlink(temp_file)
        except:
            pass


def generate_html_report(script_data: dict, test_results: dict) -> str:
    """
    Generate HTML report from test results.
    
    Args:
        script_data: Original script data from Agent 2
        test_results: Test execution results
        
    Returns:
        HTML report as string
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    success = test_results.get("success", False)
    status_color = "#28a745" if success else "#dc3545"
    status_text = "PASSED" if success else "FAILED"
    
    passed_tests = test_results.get("passed", [])
    failed_tests = test_results.get("failed", [])
    errors = test_results.get("errors", [])
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Playwright Test Report</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            line-height: 1.6;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        .status {{
            display: inline-block;
            padding: 8px 20px;
            border-radius: 20px;
            background: {status_color};
            color: white;
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 10px;
        }}
        .content {{
            padding: 30px;
        }}
        .section {{
            margin-bottom: 30px;
        }}
        .section h2 {{
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }}
        .test-list {{
            list-style: none;
        }}
        .test-item {{
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border-left: 4px solid;
        }}
        .test-item.passed {{
            background: #d4edda;
            border-color: #28a745;
        }}
        .test-item.failed {{
            background: #f8d7da;
            border-color: #dc3545;
        }}
        .test-item h3 {{
            margin-bottom: 5px;
        }}
        .error-details {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 5px;
            padding: 15px;
            margin-top: 10px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            overflow-x: auto;
        }}
        .metadata {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
        }}
        .metadata table {{
            width: 100%;
            border-collapse: collapse;
        }}
        .metadata td {{
            padding: 8px;
            border-bottom: 1px solid #dee2e6;
        }}
        .metadata td:first-child {{
            font-weight: bold;
            width: 200px;
        }}
        .stats {{
            display: flex;
            gap: 20px;
            margin: 20px 0;
        }}
        .stat-box {{
            flex: 1;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }}
        .stat-box.passed {{
            background: #d4edda;
            color: #155724;
        }}
        .stat-box.failed {{
            background: #f8d7da;
            color: #721c24;
        }}
        .stat-box h3 {{
            font-size: 2em;
            margin-bottom: 5px;
        }}
        code {{
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Playwright Test Report</h1>
            <div class="status">{status_text}</div>
            <p style="margin-top: 15px; opacity: 0.9;">Generated on {timestamp}</p>
        </div>
        
        <div class="content">
            <div class="stats">
                <div class="stat-box {'passed' if len(passed_tests) > 0 else ''}">
                    <h3>{len(passed_tests)}</h3>
                    <p>Passed</p>
                </div>
                <div class="stat-box {'failed' if len(failed_tests) > 0 else ''}">
                    <h3>{len(failed_tests)}</h3>
                    <p>Failed</p>
                </div>
                <div class="stat-box">
                    <h3>{len(errors)}</h3>
                    <p>Errors</p>
                </div>
            </div>
            
            <div class="section">
                <h2>Passed Tests</h2>
                <ul class="test-list">
"""
    
    if passed_tests:
        for test in passed_tests:
            html += f"""
                    <li class="test-item passed">
                        <h3>[OK] {test}</h3>
                    </li>
"""
    else:
        html += """
                    <li class="test-item" style="border-left-color: #ccc; background: #f8f9fa;">
                        <p>No tests passed</p>
                    </li>
"""
    
    html += """
                </ul>
            </div>
            
            <div class="section">
                <h2>Failed Tests</h2>
                <ul class="test-list">
"""
    
    if failed_tests:
        for test in failed_tests:
            html += f"""
                    <li class="test-item failed">
                        <h3>[FAILED] {test}</h3>
                    </li>
"""
    else:
        html += """
                    <li class="test-item" style="border-left-color: #ccc; background: #f8f9fa;">
                        <p>No tests failed</p>
                    </li>
"""
    
    html += """
                </ul>
            </div>
"""
    
    if errors:
        html += """
            <div class="section">
                <h2>Errors</h2>
                <ul class="test-list">
"""
        for error in errors:
            error_type = error.get("type", "Unknown")
            error_msg = error.get("message", str(error))
            html += f"""
                    <li class="test-item failed">
                        <h3>{error_type}</h3>
                        <div class="error-details">{error_msg}</div>
                    </li>
"""
        html += """
                </ul>
            </div>
"""
    
    # Add metadata
    metadata = script_data.get("metadata", {})
    description = script_data.get("description", "No description")
    
    html += f"""
            <div class="section">
                <h2>Test Information</h2>
                <div class="metadata">
                    <table>
                        <tr>
                            <td>Description</td>
                            <td>{description}</td>
                        </tr>
                        <tr>
                            <td>Model</td>
                            <td>{metadata.get('model', 'N/A')}</td>
                        </tr>
                        <tr>
                            <td>Generator</td>
                            <td>{metadata.get('generator', 'N/A')}</td>
                        </tr>
                        <tr>
                            <td>Exit Code</td>
                            <td>{test_results.get('exit_code', 'N/A')}</td>
                        </tr>
                        <tr>
                            <td>Execution Time</td>
                            <td>{timestamp}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
"""
    
    return html


async def main():
    """Main entry point for Agent 3."""
    version_manager = VersionManager()
    
    # Check for version argument
    script_version = None
    if len(sys.argv) > 1:
        try:
            script_version = int(sys.argv[1])
        except ValueError:
            print(f"[WARNING] Invalid version number: {sys.argv[1]}. Using latest script.")
    
    try:
        # Load latest script JSON
        print("[Loading] Script data...")
        script_data = version_manager.load_json("script", script_version)
        print(f"[OK] Loaded script data")
        
        # Execute Playwright script
        test_results = await execute_playwright_script(script_data)
        
        # Generate HTML report
        print("[Generating] HTML report...")
        html_report = generate_html_report(script_data, test_results)
        
        # Save report
        report_path = version_manager.save_html_report(html_report)
        
        print(f"\n[SUCCESS] Test execution complete!")
        print(f"[OK] Report saved to: {report_path}")
        
        if test_results.get("success"):
            print(f"\n[SUCCESS] All tests passed!")
        else:
            print(f"\n[WARNING] Some tests failed. Check the report for details.")
        
    except FileNotFoundError as e:
        print(f"\n[ERROR] {e}")
        print("Please run Agent 2 (script.py) first to generate script data.")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())


"""
Agent 2: Element Detection and Ordering

Reads analyze.json and creates ordered structure based on website layout.
Groups form fields with their submit buttons in exact page order.
"""
import asyncio
import json
import sys
from pathlib import Path
from typing import Dict, List
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from playwright.async_api import async_playwright, Page
from utils.config import Config
from utils.version_manager import VersionManager


async def get_fields_in_visual_order(page: Page) -> List[dict]:
    """Get all input fields in their exact visual order on the page."""
    inputs = await page.query_selector_all('input:visible, textarea:visible, select:visible')
    fields_with_pos = []
    
    for inp in inputs:
        try:
            inp_name = await inp.get_attribute('name') or ''
            inp_id = await inp.get_attribute('id') or ''
            inp_type = await inp.get_attribute('type') or 'text'
            placeholder = await inp.get_attribute('placeholder') or ''
            
            if not (inp_name or inp_id):
                continue
            
            # Get position for sorting
            box = await inp.bounding_box()
            if box:
                fields_with_pos.append({
                    'name': inp_name,
                    'type': inp_type,
                    'id': inp_id,
                    'placeholder': placeholder,
                    'y': box['y'],
                    'x': box['x']
                })
        except:
            continue
    
    # Sort by Y position (top to bottom), then X position (left to right)
    fields_with_pos.sort(key=lambda f: (f['y'], f['x']))
    
    # Remove position data, keep only field info
    return [{'name': f['name'], 'type': f['type'], 'id': f['id'], 'placeholder': f['placeholder']} 
            for f in fields_with_pos]


async def get_buttons_in_visual_order(page: Page) -> List[dict]:
    """Get all buttons in their exact visual order on the page."""
    buttons = await page.query_selector_all('button:visible, input[type="button"]:visible, input[type="submit"]:visible, [role="button"]:visible')
    buttons_with_pos = []
    
    for btn in buttons:
        try:
            btn_text = await btn.inner_text() or await btn.get_attribute('value') or ''
            btn_id = await btn.get_attribute('id') or ''
            btn_type = await btn.get_attribute('type') or 'button'
            btn_tag = await btn.evaluate('el => el.tagName.toLowerCase()')
            
            # Get position for sorting
            box = await btn.bounding_box()
            if box:
                buttons_with_pos.append({
                    'text': btn_text.strip(),
                    'type': btn_type,
                    'id': btn_id,
                    'tag': btn_tag,
                    'y': box['y'],
                    'x': box['x']
                })
        except:
            continue
    
    # Sort by Y position (top to bottom), then X position (left to right)
    buttons_with_pos.sort(key=lambda b: (b['y'], b['x']))
    
    # Remove position data, keep only button info
    return [{'text': b['text'], 'type': b['type'], 'id': b['id'], 'tag': b['tag']} 
            for b in buttons_with_pos]


async def detect_page_structure(url: str, analyze_data: dict, headless: bool = True) -> dict:
    """
    Detect page structure by reordering fields according to website visual order.
    
    Args:
        url: URL of the web page
        analyze_data: Analysis data from Agent 1 (contains buttons_with_fields)
        headless: Whether to run browser in headless mode
        
    Returns:
        Dictionary containing detected page structure with fields in website order
    """
    print(f"\nAgent 2: Detecting page structure and reordering fields")
    print("=" * 60)
    
    # Validate configuration
    Config.validate()
    
    # Step 1: First, read analyze.json to understand what buttons/tabs/fields exist
    print("\n[Step 1] Reading analyze.json to understand page structure...")
    buttons_with_fields = analyze_data.get('analysis', {}).get('buttons_with_fields', [])
    all_buttons_from_analyze = [btn_data.get('button', {}) for btn_data in buttons_with_fields]
    
    print(f"Found {len(buttons_with_fields)} buttons in analyze.json")
    print("Buttons from analyze.json:")
    for idx, btn_data in enumerate(buttons_with_fields, 1):
        btn = btn_data.get('button', {})
        btn_text = btn.get('text', '')
        fields_count = len(btn_data.get('fields', []))
        print(f"  [{idx}] '{btn_text}' - {fields_count} fields")
    
    # Step 2: Check website to get exact visual order and verify structure
    print("\n[Step 2] Checking website to get exact visual order...")
    field_order_map = {}
    button_order_map = {}
    all_fields_ordered = []
    all_buttons_ordered = []
    buttons_by_tab = {}  # Store buttons found in each tab
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=headless)
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        )
        page = await context.new_page()
        
        try:
            await page.goto(url, wait_until='networkidle', timeout=30000)
            await page.wait_for_timeout(3000)
            
            # Get all fields in visual order from initial page
            all_fields_ordered = await get_fields_in_visual_order(page)
            
            # Create order map for fields
            for idx, field in enumerate(all_fields_ordered, 1):
                key = f"{field.get('name', '')}_{field.get('id', '')}"
                field_order_map[key] = idx
            
            print(f"Found {len(all_fields_ordered)} fields in visual order (initial page)")
            
            # Get all buttons in visual order from initial page
            all_buttons_ordered = await get_buttons_in_visual_order(page)
            
            # Create order map for buttons from initial page
            for idx, button in enumerate(all_buttons_ordered, 1):
                key = f"{button.get('text', '')}_{button.get('id', '')}_{button.get('type', '')}"
                button_order_map[key] = idx
            
            # Check tabs from analyze.json - verify each tab button exists and get its content
            print("Verifying tabs from analyze.json on website...")
            tab_button_texts = []
            for btn_data in buttons_with_fields:
                btn = btn_data.get('button', {})
                btn_text = btn.get('text', '').strip()
                # Check if this might be a tab button (Individual, Organization, etc.)
                if btn_text in ['Individual', 'Organization', 'Join under organization'] or 'tab' in btn.get('class', '').lower():
                    tab_button_texts.append(btn_text)
            
            # Click each tab button from analyze.json to verify and get its content
            for tab_text in tab_button_texts:
                try:
                    print(f"  Checking tab: '{tab_text}' on website...")
                    tab_buttons = await page.query_selector_all(f'button:has-text("{tab_text}")')
                    
                    if tab_buttons:
                        tab_btn = tab_buttons[0]
                        if await tab_btn.is_visible():
                            await tab_btn.click()
                            await page.wait_for_timeout(2000)
                            try:
                                await page.wait_for_load_state('networkidle', timeout=3000)
                            except:
                                pass
                            
                            # Get buttons in this tab view
                            tab_view_buttons = await get_buttons_in_visual_order(page)
                            buttons_by_tab[tab_text] = tab_view_buttons
                            print(f"    Found {len(tab_view_buttons)} buttons in '{tab_text}' view")
                            
                            # Get fields in this tab view
                            tab_view_fields = await get_fields_in_visual_order(page)
                            print(f"    Found {len(tab_view_fields)} fields in '{tab_text}' view")
                            
                            # Add fields from this tab to the order map
                            for field in tab_view_fields:
                                key = f"{field.get('name', '')}_{field.get('id', '')}"
                                if key not in field_order_map:
                                    max_order = max(field_order_map.values()) if field_order_map else 0
                                    field_order_map[key] = max_order + 1
                                    all_fields_ordered.append(field)
                            
                            # Add buttons from this tab to order map
                            for btn in tab_view_buttons:
                                key = f"{btn.get('text', '')}_{btn.get('id', '')}_{btn.get('type', '')}"
                                if key not in button_order_map:
                                    max_order = max(button_order_map.values()) if button_order_map else 0
                                    button_order_map[key] = max_order + 1
                                    all_buttons_ordered.append(btn)
                except Exception as e:
                    print(f"    Error checking tab '{tab_text}': {e}")
                    continue
            
            # Reload page to reset
            await page.reload(wait_until='networkidle', timeout=30000)
            await page.wait_for_timeout(2000)
            
            print(f"Found {len(all_buttons_ordered)} total buttons in visual order (including tabs)")
            print(f"Found {len(all_fields_ordered)} total fields in visual order (including tabs)")
            
        finally:
            await browser.close()
    
    # Step 3: Use analyze.json data and reorder fields and buttons according to website
    print("\n[Step 3] Reordering fields and buttons according to website structure...")
    
    # Reorder buttons according to website visual order
    buttons_with_fields.sort(key=lambda b: button_order_map.get(
        f"{b.get('button', {}).get('text', '')}_{b.get('button', {}).get('id', '')}_{b.get('button', {}).get('type', '')}", 
        999
    ))
    
    # Add button order numbers
    for idx, btn_data in enumerate(buttons_with_fields, 1):
        button = btn_data.get('button', {})
        button_key = f"{button.get('text', '')}_{button.get('id', '')}_{button.get('type', '')}"
        btn_data['button_order'] = button_order_map.get(button_key, idx)
        button['order'] = btn_data['button_order']
    
    # Reorder fields for each button according to website visual order
    for btn_data in buttons_with_fields:
        fields = btn_data.get('fields', [])
        if fields:
            # Sort fields by visual order from website
            fields.sort(key=lambda f: field_order_map.get(f"{f.get('name', '')}_{f.get('id', '')}", 999))
            # Add order numbers
            for field in fields:
                key = f"{field.get('name', '')}_{field.get('id', '')}"
                field['order'] = field_order_map.get(key, 0)
    
    # Step 4: Create structured output using AI (based on analyze.json + website verification)
    print("\n[Step 4] Creating structured output with AI based on analyze.json and website pattern...")
    
    llm = ChatOpenAI(
        model=Config.OPENAI_MODEL,
        temperature=0.3,
        api_key=Config.OPENAI_API_KEY
    )
    
    system_prompt = """You are an expert web page structure analyzer. Your task is to create a structure that EXACTLY matches the website's visual pattern. 
    
The buttons_with_fields array is already sorted by button_order (visual order on website). You must create page_structure elements in the EXACT same order as buttons appear on the website.
DO NOT regroup, reorganize, or change the order - follow the button_order sequence exactly."""
    
    user_prompt = f"""Create an ordered page structure that EXACTLY matches the website pattern.

Page URL: {url}
Page Title: {analyze_data.get('page_info', {}).get('title', '')}

IMPORTANT: The buttons_with_fields array below is from analyze.json and contains ALL buttons found on the website.
The website has been verified and the visual order has been checked.

Buttons with Fields from analyze.json (already verified on website, fields in visual order):
{json.dumps(buttons_with_fields, indent=2)}

All Fields in Visual Order from Website (verified):
{json.dumps(all_fields_ordered, indent=2)}

All Buttons in Visual Order from Website (verified):
{json.dumps(all_buttons_ordered, indent=2)}

CRITICAL INSTRUCTIONS:
1. Use the buttons_with_fields data - buttons are already sorted by visual order (button_order field)
2. Fields within each button are already sorted by visual order (order field)
3. Create page_structure in EXACT order as buttons appear on the website
4. For each button in buttons_with_fields (in order), create an element that matches the website pattern:
   - If button is a tab button (Individual, Organization, etc.), create tab_group with that tab's fields
   - If button is a submit button, create form_group with form_fields and submit_button
   - If button is a navigation button, create navigation_button
5. Maintain EXACT visual sequence - first button on page = first element, second button = second element, etc.
6. DO NOT regroup or reorganize - follow the exact order from buttons_with_fields
7. Each button should appear in page_structure in the same order as it appears on the website
8. Fields within each button should be in the exact order they appear (already sorted by order field)

Return JSON in this EXACT structure:
{{
    "page_info": {{
        "url": "{url}",
        "title": "{analyze_data.get('page_info', {}).get('title', '')}"
    }},
    "page_structure": [
        {{
            "element_type": "form_group",
            "order": 1,
            "form_fields": [
                {{
                    "name": "field_name",
                    "type": "text|email|password|etc",
                    "id": "field_id",
                    "placeholder": "placeholder text",
                    "order": 1
                }}
            ],
            "submit_button": {{
                "text": "Submit button text",
                "type": "submit",
                "id": "button_id"
            }}
        }},
        {{
            "element_type": "tab_group",
            "order": 2,
            "tabs": [
                {{
                    "text": "Individual",
                    "type": "button",
                    "fields": [
                        {{
                            "name": "field_name",
                            "type": "text",
                            "id": "field_id",
                            "order": 1
                        }}
                    ]
                }}
            ]
        }},
        {{
            "element_type": "navigation_button",
            "order": 3,
            "button": {{
                "text": "Button text",
                "type": "button",
                "id": "button_id"
            }}
        }}
    ]
}}

CRITICAL RULES:
- NO counts (no total_buttons, total_fields, etc.)
- Follow buttons_with_fields array in EXACT order (already sorted by button_order)
- First button in buttons_with_fields = first element in page_structure
- Second button = second element, etc.
- DO NOT regroup buttons - each button becomes one element in page_structure
- Fields within each button are already in correct order (use them as-is)
- Match the website's exact visual pattern - buttons appear in the order they're visible on the page
- Use button_order field to determine the sequence"""
    
    
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ]
    
    response = await llm.ainvoke(messages)
    response_text = response.content
    
    # Parse AI response
    try:
        if "```json" in response_text:
            json_start = response_text.find("```json") + 7
            json_end = response_text.find("```", json_start)
            json_str = response_text[json_start:json_end].strip()
        elif "```" in response_text:
            json_start = response_text.find("```") + 3
            json_end = response_text.find("```", json_start)
            json_str = response_text[json_start:json_end].strip()
        else:
            json_start = response_text.find("{")
            json_end = response_text.rfind("}") + 1
            json_str = response_text[json_start:json_end]
        
        result = json.loads(json_str)
        
        # Sort by order
        if 'page_structure' in result:
            result['page_structure'].sort(key=lambda x: x.get('order', 999))
            
            # Ensure fields are in correct order (already reordered from website)
            for element in result['page_structure']:
                if element.get('element_type') == 'form_group' and 'form_fields' in element:
                    fields = element['form_fields']
                    # Sort fields by order (already set from website visual order)
                    fields.sort(key=lambda f: f.get('order', 999))
                
                elif element.get('element_type') == 'tab_group' and 'tabs' in element:
                    for tab in element['tabs']:
                        if 'fields' in tab:
                            fields = tab['fields']
                            # Sort fields by order (already set from website visual order)
                            fields.sort(key=lambda f: f.get('order', 999))
        
    except json.JSONDecodeError as e:
        print(f"Warning: Could not parse JSON from AI response.")
        print(f"Error: {e}")
        result = {
            "page_info": analyze_data.get('page_info', {}),
            "page_structure": []
        }
    
    # Add metadata
    result["metadata"] = {
        "analyzer": "Agent 2 (Detect)",
        "model": Config.OPENAI_MODEL,
        "url": url
    }
    
    print(f"\n[Step 4] Detection complete!")
    print(f"Created {len(result.get('page_structure', []))} grouped elements")
    
    return result


async def main():
    """Main entry point for Agent 2."""
    # Parse arguments: detect.py [URL] [analyze.json]
    url = None
    analyze_file = None
    
    if len(sys.argv) < 2:
        print("[ERROR] Missing required arguments.")
        print("Usage: python detect.py <URL> <analyze.json>")
        print("   or: python detect.py <URL>  (uses latest analyze.json)")
        print("Example: python detect.py https://example.com output/analyze5.json")
        sys.exit(1)
    
    # First argument is URL
    url = sys.argv[1]
    
    # Second argument is analyze.json (optional)
    if len(sys.argv) > 2:
        analyze_file = Path(sys.argv[2])
        if not analyze_file.exists():
            print(f"[ERROR] File not found: {analyze_file}")
            sys.exit(1)
    else:
        # Find latest analyze.json file
        output_dir = Path("output")
        analyze_files = sorted(output_dir.glob("analyze*.json"), key=lambda x: x.stat().st_mtime, reverse=True)
        
        if not analyze_files:
            print("[ERROR] No analyze.json file found. Please run analyze.py first.")
            print("Usage: python detect.py <URL> [analyze.json]")
            sys.exit(1)
        
        analyze_file = analyze_files[0]
    
    print(f"URL: {url}")
    print(f"Reading analysis from: {analyze_file.name}")
    
    # Load analyze data
    with open(analyze_file, 'r', encoding='utf-8') as f:
        analyze_data = json.load(f)
    
    headless = '--show' not in sys.argv
    
    try:
        # Detect page structure
        result = await detect_page_structure(url, analyze_data, headless=headless)
        
        # Save to detect.json
        version_manager = VersionManager()
        filepath = version_manager.save_json("detect", result)
        
        print(f"\n[SUCCESS] Detection saved to: {filepath}")
        print(f"\nPage Structure (grouped elements in exact order):")
        for idx, element in enumerate(result.get('page_structure', []), 1):
            elem_type = element.get('element_type', '')
            if elem_type == 'form_group':
                fields = element.get('form_fields', [])
                submit_btn = element.get('submit_button', {})
                print(f"  [{idx}] Form Group - Submit: '{submit_btn.get('text', '')}'")
                for field in fields:
                    print(f"      - {field.get('name', '')} ({field.get('type', '')}) [order: {field.get('order', 0)}]")
            elif elem_type == 'tab_group':
                tabs = element.get('tabs', [])
                print(f"  [{idx}] Tab Group - {len(tabs)} tabs")
                for tab in tabs:
                    fields = tab.get('fields', [])
                    print(f"      Tab: '{tab.get('text', '')}' - {len(fields)} fields")
            elif elem_type == 'navigation_button':
                btn = element.get('button', {})
                print(f"  [{idx}] Navigation - Button: '{btn.get('text', '')}'")
        
        print(f"\nNext steps:")
        print(f"   1. Review {filepath.name}")
        print(f"   2. Run: python script.py")
        
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())


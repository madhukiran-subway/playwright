"""
Script Generator: Creates Playwright scripts from scratch

Uses LangChain agent and Playwright programmatic API to generate automation scripts.
Takes URL as input and generates scripts without needing analysis files or manual interaction.
"""
import asyncio
import json
import sys
import subprocess
import tempfile
from pathlib import Path
from playwright.async_api import async_playwright, Page
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from utils.config import Config
from utils.version_manager import VersionManager


async def analyze_page_programmatically(url: str) -> dict:
    """
    Use Playwright programmatically to analyze page and generate interaction data.
    This runs automatically without manual clicks.
    
    Args:
        url: URL to analyze
        
    Returns:
        Dictionary containing page structure and interactions
    """
    print(f"\n[Step 1] Analyzing page programmatically with Playwright...")
    print("=" * 60)
    
    page_data = {
        "url": url,
        "title": "",
        "buttons": [],
        "inputs": [],
        "links": [],
        "forms": [],
        "interactions": []
    }
    
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            )
            page = await context.new_page()
            
            try:
                print(f"Navigating to: {url}")
                await page.goto(url, wait_until='networkidle', timeout=30000)
                await page.wait_for_timeout(2000)  # Wait for page to render
                
                # Get page title
                page_data["title"] = await page.title()
                print(f"Page title: {page_data['title']}")
                
                # Extract buttons
                print("Extracting buttons...")
                buttons = await page.query_selector_all('button:visible, input[type="button"]:visible, input[type="submit"]:visible, [role="button"]:visible')
                for btn in buttons:
                    try:
                        text = await btn.inner_text() or await btn.get_attribute('value') or ''
                        btn_id = await btn.get_attribute('id') or ''
                        btn_type = await btn.get_attribute('type') or 'button'
                        btn_class = await btn.get_attribute('class') or ''
                        tag = await btn.evaluate('el => el.tagName.toLowerCase()')
                        
                        # Get selector
                        if btn_id:
                            selector = f"#{btn_id}"
                        elif btn_class:
                            selector = f".{btn_class.split()[0]}"
                        else:
                            selector = f"{tag}:has-text('{text[:50]}')" if text else tag
                        
                        page_data["buttons"].append({
                            "text": text.strip(),
                            "type": btn_type,
                            "id": btn_id,
                            "class": btn_class,
                            "tag": tag,
                            "selector": selector
                        })
                    except:
                        continue
                
                print(f"Found {len(page_data['buttons'])} buttons")
                
                # Extract input fields
                print("Extracting input fields...")
                inputs = await page.query_selector_all('input:visible, textarea:visible, select:visible')
                for inp in inputs:
                    try:
                        inp_name = await inp.get_attribute('name') or ''
                        inp_id = await inp.get_attribute('id') or ''
                        inp_type = await inp.get_attribute('type') or 'text'
                        placeholder = await inp.get_attribute('placeholder') or ''
                        tag = await inp.evaluate('el => el.tagName.toLowerCase()')
                        
                        # Get selector
                        if inp_id:
                            selector = f"#{inp_id}"
                        elif inp_name:
                            selector = f"[name='{inp_name}']"
                        else:
                            selector = f"{tag}[type='{inp_type}']"
                        
                        page_data["inputs"].append({
                            "name": inp_name,
                            "type": inp_type,
                            "id": inp_id,
                            "placeholder": placeholder,
                            "tag": tag,
                            "selector": selector
                        })
                    except:
                        continue
                
                print(f"Found {len(page_data['inputs'])} input fields")
                
                # Extract links
                print("Extracting links...")
                links = await page.query_selector_all('a[href]:visible')
                for link in links:
                    try:
                        text = await link.inner_text() or ''
                        href = await link.get_attribute('href') or ''
                        link_id = await link.get_attribute('id') or ''
                        
                        if link_id:
                            selector = f"#{link_id}"
                        elif text:
                            selector = f"a:has-text('{text[:50]}')"
                        else:
                            selector = f"a[href='{href}']"
                        
                        page_data["links"].append({
                            "text": text.strip(),
                            "href": href,
                            "id": link_id,
                            "selector": selector
                        })
                    except:
                        continue
                
                print(f"Found {len(page_data['links'])} links")
                
                # Extract forms
                print("Extracting forms...")
                forms = await page.query_selector_all('form:visible')
                for form in forms:
                    try:
                        form_id = await form.get_attribute('id') or ''
                        form_action = await form.get_attribute('action') or ''
                        form_method = await form.get_attribute('method') or 'get'
                        
                        if form_id:
                            selector = f"#{form_id}"
                        elif form_action:
                            selector = f"form[action='{form_action}']"
                        else:
                            selector = "form"
                        
                        page_data["forms"].append({
                            "id": form_id,
                            "action": form_action,
                            "method": form_method,
                            "selector": selector
                        })
                    except:
                        continue
                
                print(f"Found {len(page_data['forms'])} forms")
                
                # Generate interaction suggestions based on page structure
                print("Generating interaction suggestions...")
                
                # Suggest clicking buttons that might reveal forms
                for btn in page_data["buttons"][:5]:  # Limit to first 5 buttons
                    if btn["type"] in ["button", "submit"]:
                        page_data["interactions"].append({
                            "type": "click",
                            "element": "button",
                            "selector": btn["selector"],
                            "text": btn["text"],
                            "description": f"Click '{btn['text']}' button"
                        })
                
                # Suggest filling forms
                for form in page_data["forms"]:
                    form_inputs = [inp for inp in page_data["inputs"] if inp.get("name") or inp.get("id")]
                    if form_inputs:
                        page_data["interactions"].append({
                            "type": "fill_form",
                            "form_selector": form["selector"],
                            "fields": form_inputs[:10],  # Limit to first 10 fields
                            "description": f"Fill form with {len(form_inputs)} fields"
                        })
                
            finally:
                await browser.close()
        
        print(f"Analysis complete: {len(page_data['buttons'])} buttons, {len(page_data['inputs'])} inputs, {len(page_data['links'])} links")
        return page_data
        
    except Exception as e:
        print(f"Error analyzing page: {e}")
        import traceback
        traceback.print_exc()
        return page_data


async def run_playwright_codegen(url: str, output_file: str = None) -> str:
    """
    Run Playwright codegen to generate code from URL.
    
    Args:
        url: URL to generate code for
        output_file: Optional file path to save the generated code
        
    Returns:
        Generated Playwright code as string
    """
    print(f"\n[Step 1] Running Playwright codegen for: {url}")
    print("=" * 60)
    
    # Create temporary file if output_file not provided
    if not output_file:
        temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
        output_file = temp_file.name
        temp_file.close()
    
    try:
        # Try different methods to run codegen
        commands_to_try = [
            # Method 1: Python module (most reliable on Windows)
            ['python', '-m', 'playwright', 'codegen', url, '--output', output_file, '--target', 'python'],
            # Method 2: npx (if Node.js is installed)
            ['npx', 'playwright', 'codegen', url, '--output', output_file, '--target', 'python'],
            # Method 3: Direct playwright command
            ['playwright', 'codegen', url, '--output', output_file, '--target', 'python'],
        ]
        
        generated_code = ""
        last_error = None
        
        for cmd in commands_to_try:
            try:
                print(f"Trying: {' '.join(cmd)}")
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=120,  # 2 minutes timeout
                    shell=False
                )
                
                if result.returncode == 0:
                    # Read generated code
                    if Path(output_file).exists():
                        with open(output_file, 'r', encoding='utf-8') as f:
                            generated_code = f.read()
                        if generated_code:
                            print(f"Successfully generated {len(generated_code)} characters of code")
                            return generated_code
                    else:
                        print(f"Command succeeded but output file not found")
                else:
                    last_error = result.stderr or result.stdout
                    print(f"Command failed with exit code {result.returncode}")
                    continue
                    
            except FileNotFoundError:
                # Command not found, try next method
                last_error = f"Command not found: {cmd[0]}"
                continue
            except subprocess.TimeoutExpired:
                last_error = "Command timed out"
                continue
            except Exception as e:
                last_error = str(e)
                continue
        
        # If all methods failed
        if not generated_code:
            print(f"All codegen methods failed. Last error: {last_error}")
            print("Continuing with LangChain only...")
            return ""
            
    except Exception as e:
        print(f"Error running codegen: {e}")
        return ""


async def create_script_with_langchain(url: str, page_data: dict = None, codegen_code: str = "") -> dict:
    """
    Use LangChain agent to create enhanced Playwright script.
    
    Args:
        url: URL of the page
        page_data: Page analysis data from programmatic analysis (optional)
        codegen_code: Code generated by Playwright codegen (optional)
        
    Returns:
        Dictionary containing script and metadata
    """
    print(f"\n[Step 2] Using LangChain agent to enhance script...")
    print("=" * 60)
    
    # Validate configuration
    Config.validate()
    
    # Initialize LLM
    llm = ChatOpenAI(
        model=Config.OPENAI_MODEL,
        temperature=0.3,
        api_key=Config.OPENAI_API_KEY
    )
    
    system_prompt = """You are an expert Playwright automation engineer. Your task is to create 
comprehensive Playwright test scripts.

Generate well-structured Playwright code that:
- Uses proper selectors (prefer stable selectors like id, data-testid, or semantic selectors)
- Includes proper waits and assertions
- Handles common interactions (click, fill, select, navigate)
- Includes error handling and try-catch blocks
- Follows Playwright best practices
- Uses async/await syntax
- Includes comments explaining each step
- Is production-ready and maintainable

The script should be a complete, runnable Playwright test."""
    
    # Build user prompt
    if page_data:
        # Use programmatic analysis data
        user_prompt = f"""Create a comprehensive Playwright automation script for this URL: {url}

I have analyzed the page programmatically and found:
- Title: {page_data.get('title', 'N/A')}
- Buttons: {len(page_data.get('buttons', []))} buttons
- Input Fields: {len(page_data.get('inputs', []))} inputs
- Links: {len(page_data.get('links', []))} links
- Forms: {len(page_data.get('forms', []))} forms

Page Structure:
{json.dumps(page_data, indent=2)}

Please create a Playwright script that:
1. Navigates to the URL
2. Interacts with the identified elements using the provided selectors
3. Includes proper waits and assertions
4. Handles forms and user interactions
5. Tests main user flows
6. Includes error handling

Return the script as a JSON object with this structure:
{{
    "script": "// Complete Python Playwright code here",
    "description": "Brief description of what the script does",
    "test_cases": [
        {{
            "name": "Test case name",
            "steps": ["step1", "step2", ...]
        }}
    ],
    "selectors_used": {{
        "element_name": "selector_value"
    }},
    "dependencies": ["playwright"],
    "metadata": {{
        "url": "{url}",
        "generated_from": "programmatic_analysis + langchain",
        "model": "{Config.OPENAI_MODEL}"
    }}
}}"""
    elif codegen_code:
        user_prompt = f"""Create an enhanced Playwright automation script for this URL: {url}

I have generated some initial code using Playwright codegen:
```javascript
{codegen_code}
```

Please enhance this code by:
1. Converting it to Python (if it's JavaScript)
2. Adding proper error handling
3. Adding assertions and validations
4. Improving selectors for stability
5. Adding comments and documentation
6. Making it more robust and maintainable

Return the enhanced script as a JSON object with this structure:
{{
    "script": "// Complete Python Playwright code here",
    "description": "Brief description of what the script does",
    "test_cases": [
        {{
            "name": "Test case name",
            "steps": ["step1", "step2", ...]
        }}
    ],
    "selectors_used": {{
        "element_name": "selector_value"
    }},
    "dependencies": ["playwright"],
    "metadata": {{
        "url": "{url}",
        "generated_from": "codegen + langchain",
        "model": "{Config.OPENAI_MODEL}"
    }}
}}"""
    else:
        user_prompt = f"""Create a comprehensive Playwright automation script for this URL: {url}

The script should:
1. Navigate to the URL
2. Interact with common UI elements (buttons, links, inputs, forms)
3. Include proper waits and assertions
4. Handle forms and user interactions
5. Test main user flows
6. Include error handling

Return the script as a JSON object with this structure:
{{
    "script": "// Complete Python Playwright code here",
    "description": "Brief description of what the script does",
    "test_cases": [
        {{
            "name": "Test case name",
            "steps": ["step1", "step2", ...]
        }}
    ],
    "selectors_used": {{
        "element_name": "selector_value"
    }},
    "dependencies": ["playwright"],
    "metadata": {{
        "url": "{url}",
        "generated_from": "langchain",
        "model": "{Config.OPENAI_MODEL}"
    }}
}}"""
    
    print("Generating script with LangChain...")
    
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ]
    
    # Use async invoke
    response = await llm.ainvoke(messages)
    response_text = response.content
    
    # Parse JSON from response
    try:
        if "```json" in response_text:
            json_start = response_text.find("```json") + 7
            json_end = response_text.find("```", json_start)
            json_str = response_text[json_start:json_end].strip()
        elif "```" in response_text:
            json_start = response_text.find("```") + 3
            json_end = response_text.find("```", json_start)
            json_str = response_text[json_start:json_end].strip()
        else:
            json_start = response_text.find("{")
            json_end = response_text.rfind("}") + 1
            json_str = response_text[json_start:json_end]
        
        script_data = json.loads(json_str)
    except json.JSONDecodeError as e:
        print(f"Warning: Could not parse JSON from LLM response.")
        print(f"Error: {e}")
        # Fallback: create structured response
        script_data = {
            "script": response_text,
            "description": f"Playwright script for {url}",
            "test_cases": [],
            "selectors_used": {},
            "dependencies": ["playwright"],
            "metadata": {
                "url": url,
                "generated_from": "langchain",
                "model": Config.OPENAI_MODEL,
                "error": "Could not parse JSON from LLM response"
            }
        }
    
    # Add metadata
    if "metadata" not in script_data:
        script_data["metadata"] = {}
    
    script_data["metadata"]["generator"] = "LangChain Agent + Playwright Codegen"
    script_data["metadata"]["url"] = url
    
    print("Script generation complete")
    return script_data


async def main():
    """Main entry point for script generator."""
    if len(sys.argv) < 2:
        print("Usage: python generate_script.py <URL> [--no-codegen]")
        print("Example: python generate_script.py https://example.com")
        print("         python generate_script.py https://example.com --no-codegen")
        sys.exit(1)
    
    url = sys.argv[1]
    use_codegen = '--no-codegen' not in sys.argv
    use_programmatic = '--programmatic' in sys.argv or not use_codegen
    
    print(f"\nScript Generator: Creating Playwright script from scratch")
    print(f"URL: {url}")
    print(f"Use Programmatic Analysis: {use_programmatic}")
    print(f"Use Codegen: {use_codegen}")
    print("=" * 60)
    
    page_data = None
    codegen_code = ""
    
    # Step 1: Analyze page programmatically (automatic, no manual clicks)
    if use_programmatic:
        try:
            page_data = await analyze_page_programmatically(url)
            if page_data:
                print(f"Programmatic analysis complete")
        except Exception as e:
            print(f"Error in programmatic analysis: {e}")
            print("Continuing with LangChain only...")
    
    # Step 2: Run Playwright codegen if enabled (optional, may require manual interaction)
    if use_codegen and not use_programmatic:
        try:
            codegen_code = await run_playwright_codegen(url)
            if codegen_code:
                print(f"Codegen generated {len(codegen_code)} characters")
            else:
                print("Codegen did not generate code, continuing with LangChain only")
        except Exception as e:
            print(f"Error in codegen: {e}")
            print("Continuing with LangChain only...")
    
    # Step 3: Use LangChain to create/enhance script
    try:
        script_data = await create_script_with_langchain(url, page_data, codegen_code)
        
        # Save to versioned JSON file
        version_manager = VersionManager()
        filepath = version_manager.save_json("script", script_data)
        
        print(f"\n[SUCCESS] Script saved to: {filepath}")
        print(f"\nScript Summary:")
        print(f"  Description: {script_data.get('description', 'N/A')}")
        print(f"  Test Cases: {len(script_data.get('test_cases', []))}")
        print(f"  Selectors: {len(script_data.get('selectors_used', {}))}")
        
        # Also save as Python file if script exists
        if script_data.get('script'):
            script_code = script_data['script']
            # Extract Python code if it's in a code block
            if "```python" in script_code:
                script_start = script_code.find("```python") + 8
                script_end = script_code.find("```", script_start)
                script_code = script_code[script_start:script_end].strip()
            elif "```" in script_code:
                script_start = script_code.find("```") + 3
                script_end = script_code.find("```", script_start)
                script_code = script_code[script_start:script_end].strip()
            
            # Save Python file
            py_filepath = filepath.with_suffix('.py')
            with open(py_filepath, 'w', encoding='utf-8') as f:
                f.write(script_code)
            print(f"  Python file saved to: {py_filepath.name}")
        
        print(f"\nNext steps:")
        print(f"   1. Review {filepath.name}")
        print(f"   2. Run the generated Python script")
        print(f"   3. Or run: python testresult.py")
        
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())


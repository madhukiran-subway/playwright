"""
Agent 2: Playwright Script Generator

Generates Playwright automation scripts from analysis JSON using OpenAI API and LangChain.
Outputs versioned JSON files (script1.json, script2.json, etc.).
"""
import asyncio
import json
import sys
import subprocess
import tempfile
import os
from pathlib import Path
from playwright.async_api import async_playwright, Page
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from utils.config import Config
from utils.version_manager import VersionManager


def check_tagui_available() -> bool:
    """Check if TagUI is installed and available."""
    try:
        result = subprocess.run(['tagui', '--version'], capture_output=True, text=True, timeout=5)
        return result.returncode == 0
    except:
        try:
            result = subprocess.run(['python', '-m', 'tagui', '--version'], capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except:
            return False


async def click_with_tagui(button_text: str, url: str) -> bool:
    """
    Use TagUI to click a button by text.
    
    Args:
        button_text: Text of the button to click
        url: URL of the page
        
    Returns:
        True if click was successful, False otherwise
    """
    try:
        # Create a temporary TagUI script
        tagui_script = f"""
url {url}
click '{button_text}'
"""
        temp_script = tempfile.NamedTemporaryFile(mode='w', suffix='.tag', delete=False)
        temp_script.write(tagui_script)
        temp_script.close()
        
        # Run TagUI
        result = subprocess.run(
            ['tagui', temp_script.name, '--headless'],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Clean up
        try:
            os.unlink(temp_script.name)
        except:
            pass
        
        return result.returncode == 0
    except Exception as e:
        print(f"        TagUI click error: {str(e)[:100]}")
        return False


def _generate_click_code(method_name: str, btn_text: str, button: dict) -> str:
    """Generate TypeScript code for clicking button based on method that worked."""
    if method_name == 'getByRole':
        return f"await page.getByRole('button', {{ name: '{btn_text}' }}).click();"
    elif method_name == 'getByText':
        return f"await page.getByText('{btn_text}').click();"
    elif method_name == 'locator_has_text':
        return f"await page.locator('button:has-text(\"{btn_text}\")').click();"
    elif method_name == 'locator_filter':
        return f"await page.locator('button').filter({{ hasText: '{btn_text}' }}).click();"
    elif method_name == 'locator_id' and button.get('id'):
        return f"await page.locator('#{button['id']}').click();"
    elif method_name == 'tagui':
        return f"// TagUI method: click '{btn_text}'\nawait page.getByText('{btn_text}').click(); // Fallback to Playwright"
    else:
        return f"await page.getByRole('button', {{ name: '{btn_text}' }}).click();"


async def interact_with_page_and_record(url: str, analysis_data: dict) -> dict:
    """
    Interact with live page using Playwright - click buttons and fill fields automatically.
    First extracts button names (from text key) and field names (from name key) from analyze.json,
    then compares with live URL and interacts.
    
    Args:
        url: URL to visit
        analysis_data: Analysis data from analyze.json
        
    Returns:
        Dictionary with successful interactions and selectors that worked
    """
    print(f"\n[Step 1] Extracting button and field names from analyze28.json")
    print("=" * 60)
    
    # Extract button names from 'text' key and field names from 'name' key
    buttons_with_fields = analysis_data.get('buttons_with_fields', [])
    
    print(f"\n[Fetching] Reading buttons_with_fields from JSON...")
    print(f"  Total button entries found: {len(buttons_with_fields)}")
    
    extracted_data = {
        'buttons': [],  # List of button texts
        'fields': []    # List of field names
    }
    
    print(f"\n[Extracting] Button names from 'text' key:")
    print("-" * 60)
    for idx, btn_data in enumerate(buttons_with_fields, 1):
        button = btn_data.get('button', {})
        fields = btn_data.get('fields', [])
        
        # Extract button text
        btn_text = button.get('text', '').strip()
        btn_id = button.get('id', '')
        btn_type = button.get('type', 'button')
        
        if btn_text:
            extracted_data['buttons'].append({
                'text': btn_text,
                'id': btn_id,
                'type': btn_type,
                'button_data': button
            })
            print(f"  [{idx}] Button Text: '{btn_text}'")
            print(f"      - Type: {btn_type}")
            print(f"      - ID: {btn_id if btn_id else '(no id)'}")
            print(f"      - Associated Fields: {len(fields)}")
        
        # Extract field names
        if fields:
            print(f"\n[Extracting] Field names from 'name' key for button '{btn_text}':")
            print("-" * 60)
            for field_idx, field in enumerate(fields, 1):
                field_name = field.get('name', '').strip()
                field_id = field.get('id', '')
                field_type = field.get('type', 'text')
                
                if field_name:
                    # Check if we already have this field (avoid duplicates)
                    if not any(f['name'] == field_name and f.get('button_context') == btn_text 
                              for f in extracted_data['fields']):
                        extracted_data['fields'].append({
                            'name': field_name,
                            'id': field_id,
                            'type': field_type,
                            'button_context': btn_text,  # Which button this field belongs to
                            'field_data': field
                        })
                        print(f"  [{field_idx}] Field Name: '{field_name}'")
                        print(f"      - Type: {field_type}")
                        print(f"      - ID: {field_id if field_id else '(no id)'}")
                        print(f"      - Belongs to button: '{btn_text}'")
    
    print(f"\n" + "=" * 60)
    print(f"[Summary] Extraction Complete:")
    print(f"  ✓ Total Buttons Extracted: {len(extracted_data['buttons'])}")
    print(f"  ✓ Total Fields Extracted: {len(extracted_data['fields'])}")
    print(f"\n[Buttons List]:")
    for i, btn in enumerate(extracted_data['buttons'], 1):
        print(f"  {i}. '{btn['text']}' ({btn['type']})")
    print(f"\n[Fields List]:")
    for i, field in enumerate(extracted_data['fields'], 1):
        print(f"  {i}. '{field['name']}' ({field['type']}) - Button: '{field.get('button_context', 'N/A')}'")
    print("=" * 60)
    
    print(f"\n[Step 2] Comparing extracted data with live URL: {url}")
    print("=" * 60)
    
    successful_interactions = []  # Store successful clicks and fills
    field_labels_map = {}  # Map field id/name to its label text
    button_click_methods = {}  # Store which method worked for each button
    comparison_results = {
        'buttons_found': [],
        'buttons_not_found': [],
        'fields_found': [],
        'fields_not_found': []
    }
    
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=False)  # Show browser so user can see
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            )
            page = await context.new_page()
            
            try:
                await page.goto(url, wait_until='networkidle', timeout=30000)
                await page.wait_for_timeout(2000)
                
                # Compare buttons from JSON with live page
                print(f"\n[Comparing] Buttons from JSON with live page...")
                all_page_buttons = await page.locator('button').all()
                page_button_texts = []
                for btn in all_page_buttons:
                    try:
                        btn_txt = (await btn.inner_text()).strip()
                        if btn_txt:
                            page_button_texts.append(btn_txt)
                    except:
                        pass
                
                print(f"  Found {len(page_button_texts)} buttons on live page")
                print(f"  Page buttons: {page_button_texts[:10]}")  # Show first 10
                
                for btn_info in extracted_data['buttons']:
                    btn_text = btn_info['text']
                    found = btn_text in page_button_texts
                    if found:
                        comparison_results['buttons_found'].append(btn_text)
                        print(f"  ✓ Button '{btn_text}' found on page")
                    else:
                        comparison_results['buttons_not_found'].append(btn_text)
                        print(f"  ✗ Button '{btn_text}' NOT found on page")
                
                # Compare fields from JSON with live page
                print(f"\n[Comparing] Fields from JSON with live page...")
                for field_info in extracted_data['fields']:
                    field_name = field_info['name']
                    field_id = field_info['id']
                    
                    # Try to find field by name or id
                    found = False
                    try:
                        if field_id:
                            field_elem = await page.locator(f'#{field_id}').first
                            if await field_elem.count() > 0:
                                found = True
                        if not found and field_name:
                            field_elem = await page.locator(f'[name="{field_name}"]').first
                            if await field_elem.count() > 0:
                                found = True
                    except:
                        pass
                    
                    if found:
                        comparison_results['fields_found'].append(field_name)
                        print(f"  ✓ Field '{field_name}' found on page")
                    else:
                        comparison_results['fields_not_found'].append(field_name)
                        print(f"  ✗ Field '{field_name}' NOT found on page")
                
                print(f"\n[Interacting] Clicking buttons and filling fields on live page")
                print("=" * 60)
                
                print(f"Found {len(buttons_with_fields)} buttons with fields to process")
                
                if not buttons_with_fields:
                    print("[WARNING] No buttons_with_fields found in analysis data!")
                    print("Available keys:", list(analysis_data.keys()))
                    await browser.close()
                    return {
                        'extracted_data': {'buttons': [], 'fields': []},
                        'comparison_results': {
                            'buttons_found': [],
                            'buttons_not_found': [],
                            'fields_found': [],
                            'fields_not_found': []
                        },
                        'field_labels': {},
                        'successful_interactions': [],
                        'button_click_methods': {}
                    }
                
                for btn_idx, btn_data in enumerate(buttons_with_fields):
                    button = btn_data.get('button', {})
                    fields = btn_data.get('fields', [])
                    btn_text = button.get('text', '').strip()
                    
                    if not btn_text:
                        continue
                    
                    print(f"\n  [{btn_idx + 1}/{len(buttons_with_fields)}] Processing button: '{btn_text}'")
                    
                    # First, fill fields if this button has fields
                    if fields:
                        print(f"    -> Filling {len(fields)} fields...")
                        for field in fields:
                            field_id = field.get('id', '')
                            field_name = field.get('name', '')
                            field_type = field.get('type', 'text')
                            
                            # Get label text
                            label_text = None
                            try:
                                if field_id:
                                    selector = f"#{field_id}"
                                elif field_name:
                                    selector = f"[name='{field_name}']"
                                else:
                                    continue
                                
                                label_text = await page.evaluate(f'''() => {{
                                    const field = document.querySelector('{selector}');
                                    if (!field) return null;
                                    const label = field.closest('label') || 
                                                  document.querySelector(`label[for="${{field.id}}"]`) ||
                                                  field.previousElementSibling?.tagName === 'LABEL' ? field.previousElementSibling : null;
                                    if (label) return label.textContent.trim();
                                    if (field.placeholder) return field.placeholder;
                                    if (field.getAttribute('aria-label')) return field.getAttribute('aria-label');
                                    return null;
                                }}''')
                                
                                if label_text:
                                    key = field_id or field_name
                                    field_labels_map[key] = label_text
                                    
                                # Try to fill the field
                                field_selector = f"#{field_id}" if field_id else f"[name='{field_name}']"
                                
                                # Generate test data based on field type/name
                                test_value = ""
                                if 'first' in field_name.lower() or 'fname' in field_name.lower():
                                    test_value = "John"
                                elif 'last' in field_name.lower() or 'lname' in field_name.lower():
                                    test_value = "Doe"
                                elif 'email' in field_name.lower():
                                    test_value = "test@example.com"
                                elif 'password' in field_name.lower():
                                    test_value = "Test123!@#"
                                elif 'phone' in field_name.lower() or 'mobile' in field_name.lower():
                                    test_value = "1234567890"
                                elif field_type == 'checkbox':
                                    # Just check it, don't fill
                                    try:
                                        checkbox = await page.locator(field_selector).first
                                        if await checkbox.is_visible():
                                            await checkbox.check()
                                            print(f"      ✓ Checked checkbox: {field_name or field_id}")
                                            successful_interactions.append({
                                                'type': 'checkbox',
                                                'field_name': field_name,
                                                'field_id': field_id,
                                                'label': label_text,
                                                'method': f"page.locator('{field_selector}').check()"
                                            })
                                    except:
                                        pass
                                    continue
                                else:
                                    test_value = "Test Value"
                                
                                # Try to fill the field using multiple methods
                                filled = False
                                try:
                                    # Method 1: Direct selector
                                    await page.fill(field_selector, test_value)
                                    filled = True
                                    print(f"      ✓ Filled field: {field_name or field_id} = '{test_value}'")
                                except:
                                    try:
                                        # Method 2: getByRole
                                        if label_text:
                                            await page.getByRole('textbox', name=label_text).fill(test_value)
                                            filled = True
                                            print(f"      ✓ Filled field via getByRole: {label_text} = '{test_value}'")
                                    except:
                                        pass
                                
                                if filled:
                                    successful_interactions.append({
                                        'type': 'fill',
                                        'field_name': field_name,
                                        'field_id': field_id,
                                        'label': label_text,
                                        'value': test_value,
                                        'method': f"page.getByRole('textbox', {{ name: '{label_text}' }}).fill('{test_value}')" if label_text else f"page.fill('{field_selector}', '{test_value}')"
                                    })
                            except Exception as e:
                                print(f"      ✗ Error filling field {field_name or field_id}: {e}")
                    
                    # Now try to click the button using multiple methods
                    print(f"    -> Attempting to click button: '{btn_text}'")
                    
                    # First, let's see what buttons are actually on the page
                    try:
                        all_buttons = await page.locator('button').all()
                        print(f"      Found {len(all_buttons)} buttons on page")
                        for i, btn in enumerate(all_buttons[:5]):  # Show first 5
                            try:
                                btn_txt = await btn.inner_text()
                                print(f"        Button {i+1}: '{btn_txt[:50]}'")
                            except:
                                pass
                    except Exception as e:
                        print(f"      Could not list buttons: {e}")
                    
                    button_clicked = False
                    click_method = None
                    last_error = None
                    
                    # Try multiple methods to click the button
                    async def try_getByRole():
                        try:
                            btn = page.getByRole('button', name=btn_text, exact=False)
                            count = await btn.count()
                            if count > 0:
                                await btn.first.click(timeout=5000)
                                return True
                        except Exception as e:
                            print(f"        getByRole error: {str(e)[:100]}")
                            return False
                        return False
                    
                    async def try_getByText():
                        try:
                            btn = page.getByText(btn_text, exact=False)
                            count = await btn.count()
                            if count > 0:
                                await btn.first.click(timeout=5000)
                                return True
                        except Exception as e:
                            print(f"        getByText error: {str(e)[:100]}")
                            return False
                        return False
                    
                    async def try_locator_has_text():
                        try:
                            # Escape quotes in button text
                            escaped_text = btn_text.replace('"', '\\"')
                            btn = page.locator(f'button:has-text("{escaped_text}")')
                            count = await btn.count()
                            if count > 0:
                                await btn.first.click(timeout=5000)
                                return True
                        except Exception as e:
                            print(f"        locator_has_text error: {str(e)[:100]}")
                            return False
                        return False
                    
                    async def try_locator_filter():
                        try:
                            btn = page.locator('button').filter(has_text=btn_text)
                            count = await btn.count()
                            if count > 0:
                                await btn.first.click(timeout=5000)
                                return True
                        except Exception as e:
                            print(f"        locator_filter error: {str(e)[:100]}")
                            return False
                        return False
                    
                    async def try_locator_id():
                        if button.get('id'):
                            try:
                                btn = page.locator(f'#{button.get("id")}')
                                if await btn.is_visible():
                                    await btn.click(timeout=5000)
                                    return True
                            except Exception as e:
                                return False
                        return False
                    
                    async def try_locator_text():
                        try:
                            # Try exact text match
                            escaped_text = btn_text.replace('"', '\\"')
                            btn = page.locator(f'button:has-text("{escaped_text}")').first
                            count = await btn.count()
                            if count > 0:
                                await btn.click(timeout=5000)
                                return True
                        except Exception as e1:
                            try:
                                # Try partial text match
                                btn = page.locator('button').filter(has_text=btn_text).first
                                count = await btn.count()
                                if count > 0:
                                    await btn.click(timeout=5000)
                                    return True
                            except Exception as e2:
                                print(f"        locator_text error: {str(e2)[:100]}")
                                return False
                        return False
                    
                    # Try all methods (including TagUI if available)
                    methods_to_try = [
                        ('getByRole', try_getByRole),
                        ('getByText', try_getByText),
                        ('locator_has_text', try_locator_has_text),
                        ('locator_filter', try_locator_filter),
                        ('locator_id', try_locator_id),
                        ('locator_text', try_locator_text),
                    ]
                    
                    # Add TagUI as fallback if available
                    tagui_available = check_tagui_available()
                    if tagui_available:
                        async def try_tagui():
                            try:
                                result = await click_with_tagui(btn_text, url)
                                return result
                            except Exception as e:
                                print(f"        TagUI error: {str(e)[:100]}")
                                return False
                        methods_to_try.append(('tagui', try_tagui))
                        print(f"      [TagUI] Available - will use as fallback")
                    else:
                        print(f"      [TagUI] Not available - using Playwright methods only")
                    
                    for method_name, method_func in methods_to_try:
                        try:
                            result = await method_func()
                            if result is True:
                                button_clicked = True
                                click_method = method_name
                                print(f"      ✓ Button clicked using {method_name}")
                                
                                # Record successful click
                                successful_interactions.append({
                                    'type': 'click',
                                    'button_text': btn_text,
                                    'button_id': button.get('id', ''),
                                    'method': method_name,
                                    'code': _generate_click_code(method_name, btn_text, button)
                                })
                                break
                        except Exception as e:
                            last_error = str(e)
                            print(f"      ✗ Method {method_name} failed: {e}")
                            continue
                    
                    if not button_clicked:
                        print(f"      ✗ Could not click button: '{btn_text}'")
                        if last_error:
                            print(f"         Last error: {last_error}")
                    else:
                        button_click_methods[btn_text] = click_method
                    
                    # Wait a bit after clicking
                    await page.wait_for_timeout(1000)
                
                await browser.close()
                
            except Exception as e:
                print(f"[WARNING] Error interacting with page: {e}")
                await browser.close()
                
    except Exception as e:
        print(f"[WARNING] Error opening browser: {e}")
    
    return {
        'extracted_data': extracted_data,
        'comparison_results': comparison_results,
        'field_labels': field_labels_map,
        'successful_interactions': successful_interactions,
        'button_click_methods': button_click_methods
    }


async def run_playwright_codegen(url: str) -> str:
    """
    Run Playwright codegen to generate TypeScript code from URL.
    
    Args:
        url: URL to generate code for
        
    Returns:
        Generated Playwright TypeScript code as string
    """
    print(f"\n[Running] npx playwright codegen for: {url}")
    print("=" * 60)
    
    # Create temporary file for output
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.ts', delete=False)
    output_file = temp_file.name
    temp_file.close()
    
    try:
        # Try different methods to run codegen (TypeScript target)
        commands_to_try = [
            # Method 1: npx (preferred for TypeScript)
            ['npx', 'playwright', 'codegen', url, '--output', output_file, '--target', 'typescript'],
            # Method 2: Python module
            ['python', '-m', 'playwright', 'codegen', url, '--output', output_file, '--target', 'typescript'],
            # Method 3: Direct playwright command
            ['playwright', 'codegen', url, '--output', output_file, '--target', 'typescript'],
        ]
        
        generated_code = ""
        last_error = None
        
        for cmd in commands_to_try:
            try:
                print(f"Trying: {' '.join(cmd)}")
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=120,  # 2 minutes timeout
                    shell=False
                )
                
                if result.returncode == 0:
                    # Read generated code
                    if Path(output_file).exists():
                        with open(output_file, 'r', encoding='utf-8') as f:
                            generated_code = f.read()
                        if generated_code:
                            print(f"[OK] Successfully generated {len(generated_code)} characters of code")
                            # Clean up temp file
                            try:
                                Path(output_file).unlink()
                            except:
                                pass
                            return generated_code
                    else:
                        print(f"Command succeeded but output file not found")
                else:
                    last_error = result.stderr or result.stdout
                    print(f"Command failed with exit code {result.returncode}")
                    if result.stderr:
                        print(f"Error: {result.stderr[:200]}")
                    continue
                    
            except FileNotFoundError:
                # Command not found, try next method
                last_error = f"Command not found: {cmd[0]}"
                continue
            except subprocess.TimeoutExpired:
                last_error = "Command timed out"
                continue
            except Exception as e:
                last_error = str(e)
                continue
        
        # If all methods failed
        if not generated_code:
            print(f"[WARNING] All codegen methods failed. Last error: {last_error}")
            print("Continuing with LangChain generation only...")
            return ""
            
    except Exception as e:
        print(f"[WARNING] Error running codegen: {e}")
        return ""
    finally:
        # Clean up temp file if it still exists
        try:
            if Path(output_file).exists():
                Path(output_file).unlink()
        except:
            pass


def generate_script_from_analyze_json(analysis_data: dict, url: str) -> dict:
    """
    Generate Playwright Python script directly from analyze.json data.
    No codegen or live page interaction needed.
    
    Args:
        analysis_data: Dictionary containing page analysis from analyze.json
        url: URL of the page
        
    Returns:
        Dictionary containing Playwright script
    """
    print(f"\n[Generating] Playwright Python script from analyze.json")
    print("=" * 60)
    
    # Get buttons_with_fields
    buttons_with_fields = analysis_data.get('buttons_with_fields', [])
    if not buttons_with_fields:
        buttons_with_fields = analysis_data.get('analysis', {}).get('buttons_with_fields', [])
    
    if not buttons_with_fields:
        return {
            "script": "",
            "description": "No buttons_with_fields found",
            "test_cases": [],
            "selectors_used": {},
            "dependencies": ["playwright"],
            "metadata": {"error": "No buttons_with_fields in analysis data"}
        }
    
    # Helper function to convert field name to label
    def field_name_to_label(field_name: str, field_type: str = 'text') -> str:
        """Convert field name like 'first_name' to label like 'First Name'"""
        if not field_name:
            return ""
        
        # Special mappings based on common patterns
        label_map = {
            'first_name': 'First Name',
            'last_name': 'Last Name',
            'email': 'Email',
            'password': 'Password',
            'phone_number': 'Mobile Number',
            'mobile_number': 'Mobile Number',
            'accept_terms': 'I accept the Terms and',
            'acceptTerms': 'I accept the Terms and',
            'name': 'Name',
            'message': 'Message',
            'organization_code': 'Organization Code',
            'organization_website': 'Organization Website',
            'admin_first_name': 'Admin First Name',
            'admin_last_name': 'Admin Last Name',
            'admin_email': 'Admin Email',
            'admin_password': 'Admin Password',
            'admin_phone_number': 'Admin Mobile Number',
            'size': 'Size'
        }
        
        # Check if we have a direct mapping
        if field_name in label_map:
            return label_map[field_name]
        
        # Fallback: Replace underscores with spaces and title case
        label = field_name.replace('_', ' ').title()
        # Handle special cases
        if 'email' in field_name.lower() and 'email email' in label.lower():
            label = 'Email'
        return label
    
    # Generate Python script lines
    script_lines = [
        "import asyncio",
        "from playwright.async_api import async_playwright",
        "",
        "async def run_test():",
        "    async with async_playwright() as p:",
        "        browser = await p.chromium.launch(headless=True)",
        "        context = await browser.new_context()",
        "        page = await context.new_page()",
        "",
        f"        await page.goto('{url}')",
        ""
    ]
    
    # Process all buttons and their fields
    for btn_data in buttons_with_fields:
        button = btn_data.get('button', {})
        fields = btn_data.get('fields', [])
        btn_text = button.get('text', '').strip()
        
        if not btn_text:
            continue
        
        # Process fields for this button
        for field in fields:
            field_name = field.get('name', '').strip()
            field_type = field.get('type', 'text')
            field_id = field.get('id', '')
            
            if not field_name:
                continue
            
            # Get label for the field
            field_label = field_name_to_label(field_name, field_type)
            
            # Generate test data based on field
            test_value = ""
            if 'first' in field_name.lower():
                test_value = "Madhu"
            elif 'last' in field_name.lower():
                test_value = "Kiran"
            elif 'email' in field_name.lower():
                test_value = "madhukiran3@gmail.com"
            elif 'password' in field_name.lower():
                test_value = "Madhu@123"
            elif 'phone' in field_name.lower() or 'mobile' in field_name.lower():
                test_value = "9949087134"
            elif field_type == 'checkbox':
                # For checkbox, just check it
                script_lines.append(f"        await page.get_by_role('checkbox', name='{field_label}').check()")
                continue
            else:
                test_value = "Test Value"
            
            # Add click and fill for text fields
            if field_type in ['text', 'email', 'tel', 'password', 'url']:
                script_lines.append(f"        await page.get_by_role('textbox', name='{field_label}').click()")
                script_lines.append(f"        await page.get_by_role('textbox', name='{field_label}').fill('{test_value}')")
        
        # Add button click
        script_lines.append(f"        await page.get_by_role('button', name='{btn_text}').click()")
        script_lines.append("")
    
    # Close function and add main execution
    script_lines.append("        await browser.close()")
    script_lines.append("")
    script_lines.append("if __name__ == '__main__':")
    script_lines.append("    asyncio.run(run_test())")
    
    # Store as array of lines (line by line)
    # Also keep joined version for compatibility
    script_content = "\n".join(script_lines)
    
    return {
        "script": script_content,  # Keep as string for backward compatibility
        "script_lines": script_lines,  # Store line by line as array
        "description": f"Playwright Python test script generated from analyze.json for {url}",
        "test_cases": [{
            "name": "Complete form interaction",
            "steps": [f"Navigate to {url}", "Fill all fields", "Click all buttons"]
        }],
        "selectors_used": {
            "method": "get_by_role with field labels and button text"
        },
        "dependencies": ["playwright"],
        "metadata": {
            "generated_from": "analyze28.json",
            "total_buttons": len(buttons_with_fields),
            "generator": "Agent 2 - Direct from analyze.json (Python)"
        }
    }


async def generate_playwright_script(analysis_data: dict, url: str = None, codegen_code: str = "", live_page_data: dict = None) -> dict:
    """
    Generate Playwright automation script from analysis data.
    
    Args:
        analysis_data: Dictionary containing page analysis from Agent 1
        url: URL of the page (optional, will be extracted from analysis_data if not provided)
        codegen_code: Code generated by Playwright codegen (optional)
        live_page_data: Field labels and button texts extracted from live page (optional)
        
    Returns:
        Dictionary containing Playwright script
    """
    print(f"\n[Agent 2] Generating Playwright script")
    print("=" * 60)
    
    # Get URL from analysis_data or use provided URL
    if not url:
        url = analysis_data.get('page_info', {}).get('url', '')
    
    if not url:
        print("[WARNING] No URL found in analysis data or provided as argument")
        return {
            "script": "",
            "description": "No URL provided",
            "test_cases": [],
            "selectors_used": {},
            "dependencies": ["@playwright/test"],
            "metadata": {
                "error": "No URL provided"
            }
        }
    
    # Validate configuration
    Config.validate()
    
    # Initialize LLM
    llm = ChatOpenAI(
        model=Config.OPENAI_MODEL,
        temperature=0.2,
        api_key=Config.OPENAI_API_KEY
    )
    
    # Create script generation prompt
    system_prompt = """You are an expert Playwright automation engineer. Your task is to generate 
TypeScript Playwright test scripts based on page analysis. 

Generate TypeScript Playwright code that:
- Uses multiple selector methods to ensure elements are found and clicked:
  * getByRole('textbox', { name: 'Field Name' }) for inputs
  * getByRole('button', { name: 'Button Text' }) for buttons
  * getByRole('checkbox', { name: 'Checkbox Label' }) for checkboxes
  * getByText('Button Text') as fallback for buttons
  * page.locator('button:has-text("Button Text")') as another option
  * page.locator('#id') or page.locator('[name="name"]') if needed
- ALWAYS click buttons - use ANY method that works (getByRole, getByText, locator, etc.)
- Follows the exact format: import { test, expect } from '@playwright/test';
- Uses test('test', async ({ page }) => { ... }) structure
- Includes proper interactions: click(), fill(), check()
- Navigates with page.goto()
- Uses exact field names and button text from the analysis
- Generates clean, executable TypeScript code
- CRITICAL: Every button in buttons_with_fields MUST be clicked, use multiple selector methods if needed

The script should be a complete, runnable TypeScript Playwright test."""

    # Format analysis data for prompt - focus on buttons_with_fields
    buttons_with_fields = analysis_data.get('buttons_with_fields', [])
    
    # Create simplified analysis focusing on buttons and their fields
    simplified_analysis = {
        "url": url,
        "buttons_with_fields": []
    }
    
    for btn_data in buttons_with_fields:
        button = btn_data.get('button', {})
        fields = btn_data.get('fields', [])
        
        # Map field labels from live page if available
        mapped_fields = []
        for field in fields:
            field_id = field.get('id', '')
            field_name = field.get('name', '')
            field_type = field.get('type', 'text')
            
            # Get label from live page data if available
            label_text = None
            if live_page_data and live_page_data.get('field_labels'):
                key = field_id or field_name
                label_text = live_page_data['field_labels'].get(key)
            
            # Use label, placeholder, or name as fallback
            display_name = label_text or field.get('placeholder') or field_name or field_id
            
            mapped_fields.append({
                "name": field_name,
                "id": field_id,
                "type": field_type,
                "label": display_name,  # This will be used in getByRole
                "placeholder": field.get('placeholder', '')
            })
        
        simplified_analysis["buttons_with_fields"].append({
            "button": {
                "text": button.get('text', ''),
                "type": button.get('type', 'button'),
                "id": button.get('id', '')
            },
            "fields": mapped_fields
        })
    
    analysis_str = json.dumps(simplified_analysis, indent=2)
    
    # Add URL to prompt if available
    url_context = f"\nPage URL: {url}\n" if url else ""
    
    # Add codegen code context if available
    codegen_context = ""
    if codegen_code:
        codegen_context = f"""
Playwright Codegen Generated Code (use as reference/base):
```typescript
{codegen_code}
```
"""
    
    # Add live page data context
    live_page_context = ""
    if live_page_data and live_page_data.get('field_labels'):
        live_page_context = f"""
Field Labels from Live Page (use these for getByRole 'name' parameter):
{json.dumps(live_page_data['field_labels'], indent=2)}
"""
    
    user_prompt = f"""Based on the following page analysis{' and the codegen output' if codegen_code else ''}, generate a complete TypeScript Playwright automation script.
{url_context}
{live_page_context}
{codegen_context}
Page Analysis (buttons with their fields):
{analysis_str}

Generate a TypeScript Playwright test script that:
1. Navigates to the page using page.goto('{url if url else 'URL'}')
2. For EACH button in buttons_with_fields (in order), you MUST:
   a. If button has fields, fill each field using:
      - getByRole('textbox', {{ name: 'Field Label' }}) for text inputs
      - getByRole('checkbox', {{ name: 'Field Label' }}) for checkboxes
      - Use the 'label' field from the analysis for the getByRole name parameter
      - Fill text fields with appropriate test data (e.g., 'John' for first name, 'Doe' for last name, 'test@example.com' for email, '1234567890' for phone)
   b. ALWAYS click the button using ANY of these methods (try multiple if needed):
      - page.getByRole('button', {{ name: 'Button Text' }}).click()
      - page.getByText('Button Text').click()
      - page.locator('button:has-text("Button Text")').click()
      - page.locator('button').filter({{ hasText: 'Button Text' }}).click()
      - Use exact button text from button.text field
   c. CRITICAL: Every button MUST be clicked - do not skip any buttons
3. Follow the EXACT order: process buttons_with_fields array in sequence
4. For each field, use the label from the 'label' field in the analysis
5. Use exact button text from the button.text field - click ALL buttons, not just submit buttons
{'6. Use the codegen output as a base and enhance it with the analysis data' if codegen_code else ''}

IMPORTANT: Use the EXACT format shown below. The script field must contain TypeScript code in this format:

import {{ test, expect }} from '@playwright/test';

test('test', async ({{ page }}) => {{
  await page.goto('URL');
  
  // Fill fields
  await page.getByRole('textbox', {{ name: 'Field Name' }}).click();
  await page.getByRole('textbox', {{ name: 'Field Name' }}).fill('test value');
  
  // Click buttons - use ANY method that works
  await page.getByRole('button', {{ name: 'Button Text' }}).click();
  // OR if getByRole doesn't work, use:
  // await page.getByText('Button Text').click();
  // OR: await page.locator('button:has-text("Button Text")').click();
  
  // CRITICAL: Click ALL buttons from buttons_with_fields, not just submit buttons
}});

Return the script as a JSON object with this EXACT structure:
{{
    "script": "import {{ test, expect }} from '@playwright/test';\\n\\ntest('test', async ({{ page }}) => {{\\n  // TypeScript Playwright code here\\n}});",
    "description": "Brief description of what the script does",
    "test_cases": [
        {{
            "name": "Test case name",
            "steps": ["step1", "step2", ...]
        }}
    ],
    "selectors_used": {{
        "element_name": "getByRole selector"
    }},
    "dependencies": ["@playwright/test"],
    "metadata": {{
        "generated_from": "analyzeX.json",
        "model": "..."
    }}
}}

The script field must contain valid TypeScript Playwright test code using getByRole selectors."""

    print("[Generating] Playwright script with OpenAI...")
    
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ]
    
    response = await llm.ainvoke(messages)
    response_text = response.content
    
    # Try to extract JSON from response
    try:
        # Look for JSON block in markdown code blocks
        if "```json" in response_text:
            json_start = response_text.find("```json") + 7
            json_end = response_text.find("```", json_start)
            json_str = response_text[json_start:json_end].strip()
        elif "```" in response_text:
            json_start = response_text.find("```") + 3
            json_end = response_text.find("```", json_start)
            json_str = response_text[json_start:json_end].strip()
        else:
            # Try to find JSON object directly
            json_start = response_text.find("{")
            json_end = response_text.rfind("}") + 1
            json_str = response_text[json_start:json_end]
        
        script_data = json.loads(json_str)
    except json.JSONDecodeError as e:
        print(f"[WARNING] Could not parse JSON from LLM response.")
        print(f"Error: {e}")
        # Fallback: create structured response with raw content
        script_data = {
            "script": response_text,
            "description": "Playwright script generated from analysis",
            "test_cases": [],
            "selectors_used": {},
            "dependencies": ["playwright"],
            "metadata": {
                "generated_from": "analysis",
                "model": Config.OPENAI_MODEL,
                "error": "Could not parse JSON from LLM response"
            }
        }
    
    # Add metadata
    if "metadata" not in script_data:
        script_data["metadata"] = {}
    
    script_data["metadata"]["generator"] = "Agent 2"
    script_data["metadata"]["model"] = Config.OPENAI_MODEL
    
    print("[OK] Script generation complete")
    return script_data


async def main():
    """Main entry point for Agent 2."""
    version_manager = VersionManager()
    
    # Parse command-line arguments
    analyze_json_path = None
    url = None
    
    if len(sys.argv) >= 2:
        # First argument: analyze.json file path
        analyze_json_path = sys.argv[1]
    
    if len(sys.argv) >= 3:
        # Second argument: URL
        url = sys.argv[2]
    
    try:
        # Load analysis JSON
        print("[Loading] Analysis data...")
        if analyze_json_path:
            # Load from provided file path
            analyze_path = Path(analyze_json_path)
            if not analyze_path.exists():
                print(f"[ERROR] File not found: {analyze_path}")
                sys.exit(1)
            
            with open(analyze_path, 'r', encoding='utf-8') as f:
                analysis_data = json.load(f)
            print(f"[OK] Loaded analysis data from: {analyze_path}")
        else:
            # Fallback: Load latest from version manager
            print("[WARNING] No analyze.json file provided. Loading latest analysis...")
            analysis_data = version_manager.load_json("analyze")
            print(f"[OK] Loaded latest analysis data")
        
        # Use URL from command line or from analysis data
        if url:
            print(f"[OK] Using URL from command line: {url}")
        elif analysis_data.get('page_info', {}).get('url'):
            url = analysis_data['page_info']['url']
            print(f"[OK] Using URL from analysis data: {url}")
        else:
            print("[ERROR] No URL provided. Cannot generate script.")
            print("Usage: python script.py <analyze.json> <url>")
            sys.exit(1)
        
        # Step 1: First extract data from analyze28.json (show what will be fetched)
        print(f"\n[Step 1] Fetching data from analyze28.json")
        print("=" * 60)
        
        # Extract button names and field names from JSON (just extraction, no browser yet)
        # Check both root level and nested locations
        buttons_with_fields = analysis_data.get('buttons_with_fields', [])
        if not buttons_with_fields:
            # Try alternative structure
            buttons_with_fields = analysis_data.get('analysis', {}).get('buttons_with_fields', [])
        
        print(f"[DEBUG] JSON keys: {list(analysis_data.keys())}")
        print(f"[DEBUG] Found buttons_with_fields: {len(buttons_with_fields)} entries")
        extracted_data = {
            'buttons': [],
            'fields': []
        }
        
        print(f"\n[Fetching] Reading buttons_with_fields from JSON...")
        print(f"  Total button entries found: {len(buttons_with_fields)}")
        
        print(f"\n[Extracting] Button names from 'text' key:")
        print("-" * 60)
        for idx, btn_data in enumerate(buttons_with_fields, 1):
            button = btn_data.get('button', {})
            fields = btn_data.get('fields', [])
            
            btn_text = button.get('text', '').strip()
            btn_id = button.get('id', '')
            btn_type = button.get('type', 'button')
            
            if btn_text:
                extracted_data['buttons'].append({
                    'text': btn_text,
                    'id': btn_id,
                    'type': btn_type,
                    'button_data': button
                })
                print(f"  [{idx}] Button Text: '{btn_text}'")
                print(f"      - Type: {btn_type}")
                print(f"      - ID: {btn_id if btn_id else '(no id)'}")
                print(f"      - Associated Fields: {len(fields)}")
            
            if fields:
                print(f"\n[Extracting] Field names from 'name' key for button '{btn_text}':")
                print("-" * 60)
                for field_idx, field in enumerate(fields, 1):
                    field_name = field.get('name', '').strip()
                    field_id = field.get('id', '')
                    field_type = field.get('type', 'text')
                    
                    if field_name:
                        if not any(f['name'] == field_name and f.get('button_context') == btn_text 
                                  for f in extracted_data['fields']):
                            extracted_data['fields'].append({
                                'name': field_name,
                                'id': field_id,
                                'type': field_type,
                                'button_context': btn_text,
                                'field_data': field
                            })
                            print(f"  [{field_idx}] Field Name: '{field_name}'")
                            print(f"      - Type: {field_type}")
                            print(f"      - ID: {field_id if field_id else '(no id)'}")
                            print(f"      - Belongs to button: '{btn_text}'")
        
        print(f"\n" + "=" * 60)
        print(f"[Summary] Extraction Complete:")
        print(f"  [OK] Total Buttons Extracted: {len(extracted_data['buttons'])}")
        print(f"  [OK] Total Fields Extracted: {len(extracted_data['fields'])}")
        print(f"\n[Buttons List]:")
        for i, btn in enumerate(extracted_data['buttons'], 1):
            print(f"  {i}. '{btn['text']}' ({btn['type']})")
        print(f"\n[Fields List]:")
        for i, field in enumerate(extracted_data['fields'], 1):
            print(f"  {i}. '{field['name']}' ({field['type']}) - Button: '{field.get('button_context', 'N/A')}'")
        print("=" * 60)
        
        # Step 2: Generate Playwright script directly from analyze.json
        print(f"\n[Step 2] Generating Playwright script from analyze.json")
        print("=" * 60)
        script_data = generate_script_from_analyze_json(analysis_data, url)
        
        # Save to versioned JSON file
        filepath = version_manager.save_json("script", script_data)
        
        print(f"\n[SUCCESS] Script saved to: {filepath}")
        print(f"\n[Next steps]:")
        print(f"   1. Review {filepath.name}")
        print(f"   2. Run: python testresult.py")
        
    except FileNotFoundError as e:
        print(f"\n[ERROR] {e}")
        print("Please run Agent 1 (analyze.py) first to generate analysis data.")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())


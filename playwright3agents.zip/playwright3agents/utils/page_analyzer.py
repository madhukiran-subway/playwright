"""Utility for fetching and parsing web page content."""
import aiohttp
from bs4 import BeautifulSoup
from typing import Dict, List, Any


async def fetch_page_content(url: str) -> Dict[str, Any]:
    """Fetch and parse web page content."""
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
            if response.status != 200:
                raise Exception(f"Failed to fetch page: HTTP {response.status}")
            
            html = await response.text()
            soup = BeautifulSoup(html, 'html.parser')
            
            # Extract basic page information
            title = soup.find('title')
            title_text = title.get_text(strip=True) if title else "No title"
            
            # Extract meta information
            meta_description = ""
            meta_tag = soup.find('meta', attrs={'name': 'description'})
            if meta_tag:
                meta_description = meta_tag.get('content', '')
            
            return {
                "url": url,
                "title": title_text,
                "meta_description": meta_description,
                "html_content": html,
                "html_length": len(html)
            }


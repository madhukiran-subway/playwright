"""Version manager for tracking and incrementing output file versions."""
import os
import json
import re
from pathlib import Path
from typing import Optional


class VersionManager:
    """Manages versioning for output files."""
    
    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
    
    def get_next_version(self, prefix: str) -> int:
        """Get the next version number for a given prefix."""
        existing_files = list(self.output_dir.glob(f"{prefix}*.json"))
        if not existing_files:
            return 1
        
        versions = []
        for file in existing_files:
            match = re.search(rf"{prefix}(\d+)\.json", file.name)
            if match:
                versions.append(int(match.group(1)))
        
        return max(versions) + 1 if versions else 1
    
    def get_next_report_version(self, prefix: str = "report") -> int:
        """Get the next version number for HTML reports."""
        existing_files = list(self.output_dir.glob(f"{prefix}*.html"))
        if not existing_files:
            return 1
        
        versions = []
        for file in existing_files:
            match = re.search(rf"{prefix}(\d+)\.html", file.name)
            if match:
                versions.append(int(match.group(1)))
        
        return max(versions) + 1 if versions else 1
    
    def save_json(self, prefix: str, data: dict) -> Path:
        """Save JSON data with versioned filename."""
        version = self.get_next_version(prefix)
        filename = f"{prefix}{version}.json"
        filepath = self.output_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"Saved {filepath}")
        return filepath
    
    def load_json(self, prefix: str, version: Optional[int] = None) -> dict:
        """Load JSON data from versioned filename."""
        if version:
            filename = f"{prefix}{version}.json"
        else:
            # Load latest version
            existing_files = list(self.output_dir.glob(f"{prefix}*.json"))
            if not existing_files:
                raise FileNotFoundError(f"No {prefix}*.json files found")
            
            versions = []
            for file in existing_files:
                match = re.search(rf"{prefix}(\d+)\.json", file.name)
                if match:
                    versions.append((int(match.group(1)), file))
            
            if not versions:
                raise FileNotFoundError(f"No {prefix}*.json files found")
            
            _, latest_file = max(versions, key=lambda x: x[0])
            filename = latest_file.name
        
        filepath = self.output_dir / filename
        if not filepath.exists():
            raise FileNotFoundError(f"File not found: {filepath}")
        
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save_html_report(self, html_content: str) -> Path:
        """Save HTML report with versioned filename."""
        version = self.get_next_report_version()
        filename = f"report{version}.html"
        filepath = self.output_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"Saved report: {filepath}")
        return filepath


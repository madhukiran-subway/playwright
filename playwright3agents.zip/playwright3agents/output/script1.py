// Complete Python Playwright code here
import asyncio
from playwright.async_api import async_playwright

async def run(playwright):
    try:
        # Launch the browser and open a new page
        browser = await playwright.chromium.launch(headless=False)
        page = await browser.new_page()

        # Navigate to the signup page
        await page.goto('https://skill.aihiringpatner.com/signup')

        # Wait for the signup form to be visible
        await page.wait_for_selector('form#signup-form')

        # Fill in the signup form
        await page.fill('input[name="first_name"]', 'John')
        await page.fill('input[name="last_name"]', 'Doe')
        await page.fill('input[name="email"]', 'john.doe@example.com')
        await page.fill('input[name="password"]', 'SecurePassword123')
        await page.fill('input[name="confirm_password"]', 'SecurePassword123')

        # Click the signup button
        await page.click('button[type="submit"]')

        # Wait for the confirmation message or redirection
        await page.wait_for_selector('text=Welcome, John')

        # Assert that the user is redirected to the welcome page
        assert 'welcome' in page.url, "User was not redirected to the welcome page"

    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        # Close the browser
        await browser.close()

async def main():
    async with async_playwright() as playwright:
        await run(playwright)

# Run the main function
asyncio.run(main())